/* Modal WASM kernel, assembled at load time: no toolchain and no .wasm file to ship.
 *   tc(n)        Warshall transitive closure of the n×n byte matrix R at offset 0
 *   mod(n, dia)  box (dia=0) or diamond (dia=1) of valuation V at 4096 -> OUT at 4160
 * n <= 64. Falls back to plain JS when WebAssembly is unavailable. */
(function (root) {
  var V = 4096, OUT = 4160;
  var u = function (n) { var o = []; do { var b = n & 127; n >>>= 7; o.push(n ? b | 128 : b); } while (n); return o; };
  var s = function (n) { var o = []; for (;;) { var b = n & 127; n >>= 7; if ((n === 0 && !(b & 64)) || (n === -1 && (b & 64))) { o.push(b); return o; } o.push(b | 128); } };
  var vec = function (a) { return u(a.length).concat(a); };
  var sec = function (id, a) { return [id].concat(u(a.length), a); };
  var str = function (t) { return vec(Array.from(t).map(function (c) { return c.charCodeAt(0); })); };
  var cat = function () { return [].concat.apply([], arguments); };
  var get = function (i) { return [0x20, i]; }, set = function (i) { return [0x21, i]; };
  var k = function (n) { return [0x41].concat(s(n)); };
  var ADD = [0x6a], SUB = [0x6b], MUL = [0x6c], AND = [0x71], OR = [0x72], EQZ = [0x45], GE = [0x4e], SEL = [0x1b];
  var ld = function (addr) { return cat(addr, [0x2d, 0, 0]); };            // i32.load8_u
  var st = function (addr, val) { return cat(addr, val, [0x3a, 0, 0]); };  // i32.store8
  var idx = function (a, b) { return cat(get(a), get(0), MUL, get(b), ADD); }; // a*n+b
  /* for (local v = 0; v < n; v++) body */
  var loop = function (v, body) {
    return cat(k(0), set(v), [0x02, 0x40, 0x03, 0x40], get(v), get(0), GE, [0x0d, 1],
      body, get(v), k(1), ADD, set(v), [0x0c, 0, 0x0b, 0x0b]);
  };

  function build() {
    // tc(n): locals 1=k 2=i 3=j.  R[i][j] |= R[i][k] & R[k][j]
    var cell = idx(2, 3);
    var tc = loop(1, loop(2, loop(3, st(cell, cat(ld(idx(2, 1)), ld(idx(1, 3)), AND, ld(cell), OR)))));
    // mod(n, dia): locals 2=w 3=v 4=acc.  term = dia ? r&x : (!r)|x ;  acc = dia ? acc|term : acc&term
    var r = ld(idx(2, 3)), x = ld(cat(k(V), get(3), ADD));
    var term = cat(r, x, AND, r, EQZ, x, OR, get(1), SEL);
    var step = cat(get(4), term, OR, get(4), term, AND, get(1), SEL, set(4));
    var md = loop(2, cat(k(1), get(1), SUB, set(4), loop(3, step), st(cat(k(OUT), get(2), ADD), get(4))));
    var fn = function (code) { return vec(cat([1, 3, 0x7f], code, [0x0b])); };
    return new Uint8Array(cat(
      [0, 0x61, 0x73, 0x6d, 1, 0, 0, 0],
      sec(1, cat([2], [0x60, 1, 0x7f, 0], [0x60, 2, 0x7f, 0x7f, 0])),
      sec(3, [2, 0, 1]),
      sec(5, [1, 0, 1]),
      sec(7, cat([3], str('mem'), [2, 0], str('tc'), [0, 0], str('mod'), [0, 1])),
      sec(10, cat([2], fn(tc), fn(md)))));
  }

  function fallback() {
    var m = new Uint8Array(4300);
    return {
      mem: { buffer: m.buffer },
      tc: function (n) { for (var a = 0; a < n; a++) for (var i = 0; i < n; i++) for (var j = 0; j < n; j++) m[i * n + j] |= m[i * n + a] & m[a * n + j]; },
      mod: function (n, d) { for (var w = 0; w < n; w++) { var c = d ? 0 : 1; for (var v = 0; v < n; v++) { var q = m[w * n + v], y = m[V + v]; c = d ? (c | (q & y)) : (c & ((!q || y) ? 1 : 0)); } m[OUT + w] = c; } }
    };
  }

  /** Resolves to { engine, closure(R,n), modal(R,val,n,dia) }; engine is "wasm" or "js". */
  function load() {
    var make = function (ex, engine) {
      var m = new Uint8Array(ex.mem.buffer);
      return {
        engine: engine,
        closure: function (R, n) { m.set(R, 0); ex.tc(n); return m.slice(0, n * n); },
        modal: function (R, val, n, dia) { m.set(R, 0); m.set(val, V); ex.mod(n, dia ? 1 : 0); return m.slice(OUT, OUT + n); }
      };
    };
    if (typeof WebAssembly === 'undefined') return Promise.resolve(make(fallback(), 'js'));
    return WebAssembly.instantiate(build()).then(
      function (r) { return make(r.instance.exports, 'wasm'); },
      function () { return make(fallback(), 'js'); });
  }

  var api = { load: load, bytes: build };
  root.ModalWasm = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
