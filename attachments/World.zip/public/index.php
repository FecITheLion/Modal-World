<?php
declare(strict_types=1);

use ModalApp\{Respond, Snowflake, OAuth, View, Symbols};
use ModalLogic\{ModalWorlds, ModalWorldObject};

$root = dirname(__DIR__);
if (is_file("$root/vendor/autoload.php")) {
    require "$root/vendor/autoload.php";            // composer require smarty/smarty
}
spl_autoload_register(function (string $c) use ($root): void {
    $f = "$root/src/" . substr($c, strrpos($c, '\\') + 1) . '.php';
    if (strpos($c, 'ModalApp\\') === 0 && is_file($f)) {
        require_once $f;
    }
});
require "$root/src/modal_worlds.php";
require_once "$root/src/Respond.php";

header_remove('Set-Cookie');                         // this app never sets cookies
$ini = is_file("$root/.env") ? parse_ini_file("$root/.env", false, INI_SCANNER_RAW) : [];
$cfg = function (string $k, ?string $d = null) use ($ini): ?string {
    $v = getenv($k);
    return ($v !== false && $v !== '') ? $v : ($ini[$k] ?? $d);
};

$base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
$path = trim(substr((string) parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), strlen($base)), '/');

/** The sample Kripke model every representation is built from. */
function sampleModel(): ModalWorlds
{
    $m = new ModalWorlds();
    $m->addWorld(new ModalWorldObject('w0', ['P', 'Q'], 'actual'))
      ->addWorld(new ModalWorldObject('w1', ['P']))
      ->addWorld(new ModalWorldObject('w2', ['P', 'Q']));
    return $m->connect('w0', 'w1')->connect('w0', 'w2')->connect('w1', 'w2');
}

function modelArray(ModalWorlds $m): array
{
    $w = [];
    foreach ($m->ids() as $id) {
        $w[] = ['id' => $id, 'P' => $m->world($id)->holds('P'), 'Q' => $m->world($id)->holds('Q')];
    }
    return ['worlds' => $w, 'relation' => $m->relation(), 'frame' => [
        'reflexive' => $m->isReflexive(), 'serial' => $m->isSerial(), 'symmetric' => $m->isSymmetric(),
        'transitive' => $m->isTransitive(), 'euclidean' => $m->isEuclidean()]];
}

function modelLd(ModalWorlds $m): array
{
    $g = [];
    foreach ($m->ids() as $id) {
        $g[] = ['@id' => "#$id", '@type' => 'World', 'true' => $m->world($id)->trueAtoms(),
                'accessibleTo' => array_map(function ($t) { return "#$t"; }, $m->accessibleFrom($id))];
    }
    return ['@context' => ['@vocab' => 'https://www.cmdr.site/ns/modal#', 'true' => ['@container' => '@set'],
        'accessibleTo' => ['@type' => '@id', '@container' => '@set']], '@graph' => $g];
}

function modelSvg(ModalWorlds $m): string
{
    $ids = $m->ids();
    $n = count($ids);
    $pos = [];
    foreach ($ids as $i => $id) {
        $a = 2 * M_PI * $i / max(1, $n) - M_PI / 2;
        $pos[$id] = [200 + 130 * cos($a), 200 + 130 * sin($a)];
    }
    $o = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" font-family="sans-serif" text-anchor="middle">'
       . '<defs><marker id="a" markerWidth="8" markerHeight="8" refX="26" refY="4" orient="auto"><path d="M0 0L8 4L0 8z" fill="#888"/></marker></defs>';
    foreach ($m->relation() as [$f, $t]) {
        $o .= $f === $t ? '' : sprintf('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="#888" marker-end="url(#a)"/>', $pos[$f][0], $pos[$f][1], $pos[$t][0], $pos[$t][1]);
    }
    foreach ($ids as $id) {
        $o .= sprintf('<g transform="translate(%.1f %.1f)"><circle r="26" fill="#eef" stroke="#447"/><text y="-2" font-size="13">%s</text><text y="14" font-size="11">%s</text></g>',
            $pos[$id][0], $pos[$id][1], htmlspecialchars($id), htmlspecialchars(implode(' ', $m->world($id)->trueAtoms())));
    }
    return $o . '</svg>';
}

try {
    switch ($path) {
        case '':
            $m = sampleModel();
            $json = function () use ($m): string { return json_encode(modelArray($m), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT); };
            Respond::negotiate([
                'text/html' => function () use ($root, $base, $m, $cfg): string {
                    $seed = json_encode(modelArray($m), JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE);
                    return (new View($root))->render('mosaic.tpl', [
                        'base' => $base, 'groups' => Symbols::groups(), 'seed' => $seed,
                        'provider' => $cfg('DEFAULT_PROVIDER', 'github')], 'mosaic|' . md5($base));
                },
                'application/ld+json' => function () use ($m): string { return json_encode(modelLd($m), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT); },
                'application/json' => $json,
                'image/svg+xml' => function () use ($m): string { return modelSvg($m); },
                'text/csv' => function () use ($m): string {
                    return "from,to\n" . implode("\n", array_map(function ($p) { return "$p[0],$p[1]"; }, $m->relation())) . "\n";
                },
                'text/plain' => function () use ($m): string { return $m->render() . "\n"; },
            ]);
            break;

        case 'schema/oauth':
            $ctx = (string) file_get_contents("$root/schema/oauth-login.context.jsonld");
            Respond::negotiate([
                'application/ld+json' => function () use ($ctx): string { return $ctx; },
                'application/json' => function () use ($ctx): string { return $ctx; },
            ], 'public, max-age=3600');
            break;

        case 'auth/login':
            $db = new Snowflake($cfg);
            $id = preg_replace('~[^A-Za-z0-9_.-]~', '', (string) ($_GET['id'] ?? $cfg('DEFAULT_PROVIDER', 'github')));
            header('Cache-Control: no-store');
            header('Location: ' . (new OAuth($db, $cfg, "$root/var/cache"))->loginUrl($id), true, 302);
            break;

        case 'auth/callback':
            $t = (new OAuth(new Snowflake($cfg), $cfg, "$root/var/cache"))
                ->exchange((string) ($_GET['code'] ?? ''), (string) ($_GET['state'] ?? ''));
            $frag = http_build_query(array_intersect_key($t, array_flip(['access_token', 'token_type', 'expires_in'])));
            header('Cache-Control: no-store');
            header('Referrer-Policy: no-referrer');
            header("Location: $base/#$frag", true, 302);   // fragment: never sent to any server or log
            break;

        default:
            Respond::text(404, 'Not found');
    }
} catch (Throwable $e) {
    error_log((string) $e);
    Respond::text(502, 'Request failed: ' . $e->getMessage());
}
