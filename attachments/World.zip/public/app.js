(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return [].slice.call((r || document).querySelectorAll(s)); };
  var seed = JSON.parse($('#seed').textContent);
  var MAX = 64;
  var S = { worlds: seed.worlds.map(function (w) { return { P: !!w.P, Q: !!w.Q }; }), atom: 'P', src: null, drag: null, k: null, token: null };
  var n = function () { return S.worlds.length; };
  var mosaic = $('#mosaic');

  var pack = function () { var N = n(), a = new Uint8Array(N * N); for (var i = 0; i < N; i++) for (var j = 0; j < N; j++) a[i * N + j] = S.M[i][j]; return a; };
  S.M = [];                                       // adjacency as arrays; packed for the kernel
  for (var i = 0; i < n(); i++) { S.M.push(new Array(n()).fill(0)); }
  seed.relation.forEach(function (p) { S.M[+p[0].slice(1)][+p[1].slice(1)] = 1; });
  var unpack = function (a) { var N = n(); for (var i = 0; i < N; i++) for (var j = 0; j < N; j++) S.M[i][j] = a[i * N + j]; };

  /* ---- mutations ---- */
  var toggle = function (a, b) { S.M[a][b] = S.M[a][b] ? 0 : 1; };
  var addWorld = function () {
    if (n() >= MAX) return;
    S.worlds.push({ P: false, Q: false });
    S.M.forEach(function (r) { r.push(0); }); S.M.push(new Array(n()).fill(0));
  };
  var removeWorld = function (i) {
    if (n() <= 1) return;
    S.worlds.splice(i, 1); S.M.splice(i, 1); S.M.forEach(function (r) { r.splice(i, 1); }); S.src = null;
  };
  var close = function (sys) {
    var N = n(), m = S.M, i, j;
    var refl = /T|B|S/.test(sys), sym = /B|S5/.test(sys), tra = /S/.test(sys);
    if (sys === 'D') for (i = 0; i < N; i++) if (!m[i].some(Boolean)) m[i][i] = 1;
    if (refl) for (i = 0; i < N; i++) m[i][i] = 1;
    if (sym) for (i = 0; i < N; i++) for (j = 0; j < N; j++) if (m[i][j]) m[j][i] = 1;
    if (tra && S.k) unpack(S.k.closure(pack(), N));   // Warshall in the WASM kernel
  };

  /* ---- frame facts ---- */
  var facts = function () {
    var N = n(), m = S.M, f = { serial: true, reflexive: true, symmetric: true, transitive: true, euclidean: true }, i, j, k;
    for (i = 0; i < N; i++) {
      if (!m[i].some(Boolean)) f.serial = false;
      if (!m[i][i]) f.reflexive = false;
      for (j = 0; j < N; j++) if (m[i][j]) {
        if (!m[j][i]) f.symmetric = false;
        for (k = 0; k < N; k++) { if (m[j][k] && !m[i][k]) f.transitive = false; if (m[i][k] && !m[j][k]) f.euclidean = false; }
      }
    }
    return f;
  };

  /* ---- render ---- */
  function render() {
    var N = n(), a = S.atom, val = new Uint8Array(N), R = pack(), box = [], dia = [], i, j;
    S.worlds.forEach(function (w, x) { val[x] = w[a] ? 1 : 0; });
    if (S.k) { box = S.k.modal(R, val, N, false); dia = S.k.modal(R, val, N, true); }
    var to = S.src == null ? [] : S.M[S.src];
    mosaic.innerHTML = '';
    S.worlds.forEach(function (w, x) {
      var el = document.createElement('div');
      el.className = 'w' + (S.src === x ? ' src' : '') + (to[x] ? ' to' : '');
      el.dataset.i = x; el.tabIndex = 0; el.setAttribute('role', 'button');
      var succ = []; for (j = 0; j < N; j++) if (S.M[x][j]) succ.push('w' + j);
      el.innerHTML = '<header><span>w' + x + '</span><button class="x" data-del title="remove world" aria-label="remove w' + x + '">×</button></header>' +
        '<div class="atoms"><button data-a="P" aria-pressed="' + w.P + '">P</button><button data-a="Q" aria-pressed="' + w.Q + '">Q</button></div>' +
        '<div class="mods"><span class="' + (box[x] ? 't' : 'f') + '">□' + a + ' ' + (box[x] ? '✓' : '✗') + '</span> <span class="' + (dia[x] ? 't' : 'f') + '">◇' + a + ' ' + (dia[x] ? '✓' : '✗') + '</span></div>' +
        '<div class="succ">R → ' + (succ.join(', ') || '∅') + '</div>';
      mosaic.appendChild(el);
    });
    var f = facts();
    $('#facts').innerHTML = Object.keys(f).map(function (k) { return '<span class="' + (f[k] ? 'on' : '') + '">' + (f[k] ? '✓ ' : '') + k + '</span>'; }).join('');
    $('#atomName').textContent = a;
    $('#engine').textContent = S.k ? S.k.engine : '…';
  }

  /* ---- fit the grid to its container (flex/grid that follows the viewport) ---- */
  function fit() {
    var w = mosaic.clientWidth || window.innerWidth, c = Math.max(1, Math.min(n(), Math.floor(w / 150)));
    mosaic.style.setProperty('--cols', c);
  }
  if (window.ResizeObserver) new ResizeObserver(fit).observe(mosaic); else window.addEventListener('resize', fit);

  /* ---- pointer input: one code path for mouse, pen and touch ---- */
  mosaic.addEventListener('pointerdown', function (e) {
    var w = e.target.closest('.w');
    S.drag = (w && !e.target.closest('button')) ? +w.dataset.i : null;
  });
  mosaic.addEventListener('pointermove', function (e) {
    if (S.drag == null) return;
    var el = document.elementFromPoint(e.clientX, e.clientY), w = el && el.closest('.w');
    $$('.w.drop', mosaic).forEach(function (d) { d.classList.remove('drop'); });
    if (w && +w.dataset.i !== S.drag) w.classList.add('drop');
  });
  document.addEventListener('pointercancel', function () { S.drag = null; });
  document.addEventListener('pointerup', function (e) {
    if (S.drag == null) return;
    var from = S.drag, el = document.elementFromPoint(e.clientX, e.clientY), w = el && el.closest && el.closest('.w');
    S.drag = null;
    if (!w) return render();
    var to = +w.dataset.i;
    if (to !== from) { toggle(from, to); S.src = null; }                       // drag A onto B
    else if (S.src != null && S.src !== from) { toggle(S.src, from); S.src = null; } // tap A, then tap B
    else S.src = S.src === from ? null : from;
    render();
  });
  mosaic.addEventListener('click', function (e) {                              // buttons inside tiles
    var tile = e.target.closest('.w'); if (!tile) return;
    var i = +tile.dataset.i, b = e.target.closest('button');
    if (!b) return;
    if (b.dataset.a) S.worlds[i][b.dataset.a] = !S.worlds[i][b.dataset.a];
    if (b.hasAttribute('data-del')) removeWorld(i);
    render();
  });
  mosaic.addEventListener('keydown', function (e) {                            // keyboard: Enter/Space = tap
    var w = e.target.closest && e.target.closest('.w');
    if (!w || e.target.closest('button') || (e.key !== 'Enter' && e.key !== ' ')) return;
    e.preventDefault(); var i = +w.dataset.i;
    if (S.src != null && S.src !== i) { toggle(S.src, i); S.src = null; } else S.src = S.src === i ? null : i;
    render(); var again = $('.w[data-i="' + i + '"]', mosaic); if (again) again.focus();
  });

  /* ---- toolbar ---- */
  $('.tools').addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b) return;
    if (b.dataset.sys) close(b.dataset.sys);
    else if (b.dataset.act === 'add') addWorld();
    else if (b.dataset.act === 'atom') S.atom = S.atom === 'P' ? 'Q' : 'P';
    else if (b.dataset.act === 'clear') S.M.forEach(function (r) { r.fill(0); });
    fit(); render();
  });

  /* ---- symbols: filter by datalist input, click to insert ---- */
  var q = $('#q');
  q.addEventListener('input', function () {
    var t = q.value.trim().split(/\s+/).pop().toLowerCase();
    $$('details').forEach(function (d) {
      var hit = 0;
      $$('.sym', d).forEach(function (s) { var show = !t || s.dataset.k.toLowerCase().indexOf(t) > -1; s.hidden = !show; hit += show; });
      d.hidden = !hit; if (t && hit) d.open = true;
    });
  });
  var insert = function (s) { q.value += (q.value && !/\s$/.test(q.value) ? ' ' : '') + s.dataset.s; q.focus(); };
  document.addEventListener('click', function (e) { var s = e.target.closest('.sym'); if (s) insert(s); });
  document.addEventListener('keydown', function (e) { var s = e.target.closest && e.target.closest('.sym'); if (s && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); insert(s); } });

  /* ---- login: the token arrives in the URL fragment and lives only in this page's memory ---- */
  if (location.hash.length > 1) {
    var h = new URLSearchParams(location.hash.slice(1));
    if (h.get('access_token')) {
      S.token = h.get('access_token');
      $('#login').hidden = true; $('#who').hidden = false;
      history.replaceState(null, '', location.pathname + location.search);
    }
  }
  window.modalFetch = function (url, opt) {      // use for any authenticated call; no cookies involved
    opt = opt || {}; opt.headers = Object.assign({}, opt.headers, S.token ? { Authorization: 'Bearer ' + S.token } : {});
    opt.credentials = 'omit'; return fetch(url, opt);
  };

  fit(); render();
  window.ModalWasm.load().then(function (k) { S.k = k; render(); });
})();
