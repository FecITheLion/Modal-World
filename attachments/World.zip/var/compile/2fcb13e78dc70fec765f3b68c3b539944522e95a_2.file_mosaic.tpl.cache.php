<?php
/* Smarty version 5.8.5, created on 2026-10-17 22:05:54
  from 'file:mosaic.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.8.5',
  'unifunc' => 'content_6ad3d522a67392_26635371',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2fcb13e78dc70fec765f3b68c3b539944522e95a' => 
    array (
      0 => 'mosaic.tpl',
      1 => 1792265943,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_6ad3d522a67392_26635371 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\Modal\\templates';
$_smarty_tpl->getCompiled()->nocache_hash = '5817924736ad3d5227fd3e1_35745159';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Modal worlds mosaic</title>
<link rel="stylesheet" href="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('base')), ENT_QUOTES, 'UTF-8');?>
/app.css">
<?php echo '<script'; ?>
 src="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('base')), ENT_QUOTES, 'UTF-8');?>
/wasm.js" defer><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('base')), ENT_QUOTES, 'UTF-8');?>
/app.js" defer><?php echo '</script'; ?>
>
</head>
<body>
<header class="bar">
  <h1>Modal worlds</h1>
  <label class="find">Find or build with a symbol
    <input id="q" list="symbols" autocomplete="off" spellcheck="false" placeholder="□  ◇  K  U  …">
  </label>
  <datalist id="symbols"><?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('groups'), 'g');
$_smarty_tpl->getVariable('g')->index = -1;
$foreach0DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('g')->value) {
$foreach0DoElse = false;
$_smarty_tpl->getVariable('g')->index++;
$_smarty_tpl->getVariable('g')->first = !$_smarty_tpl->getVariable('g')->index;
$foreach0Backup = clone $_smarty_tpl->getVariable('g');
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('g')['items'], 'i');
$foreach1DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('i')->value) {
$foreach1DoElse = false;
?><option value="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('i')['sym']), ENT_QUOTES, 'UTF-8');?>
" label="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('i')['name']), ENT_QUOTES, 'UTF-8');?>
"><?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);
$_smarty_tpl->setVariable('g', $foreach0Backup);
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?></datalist>
  <span class="grow"></span>
  <span id="engine" class="chip" title="Engine computing □, ◇ and closures">…</span>
  <a class="btn" id="login" href="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('base')), ENT_QUOTES, 'UTF-8');?>
/auth/login?id=<?php echo rawurlencode((string)$_smarty_tpl->getValue('provider'));?>
" rel="nofollow">Sign in</a>
  <span id="who" class="chip" hidden>signed in</span>
</header>

<main class="layout">
  <section class="panel" aria-label="Worlds">
    <div class="tools" role="toolbar" aria-label="Frame tools">
      <button type="button" data-act="add">+ world</button>
      <button type="button" data-act="atom" aria-pressed="false">atom: <b id="atomName">P</b></button>
      <span class="grow"></span>
      <button type="button" data-sys="D" title="serial">D</button>
      <button type="button" data-sys="T" title="reflexive">T</button>
      <button type="button" data-sys="B" title="reflexive + symmetric">B</button>
      <button type="button" data-sys="S4" title="reflexive + transitive">S4</button>
      <button type="button" data-sys="S5" title="equivalence relation">S5</button>
      <button type="button" data-act="clear">clear R</button>
    </div>
    <div id="mosaic" class="mosaic" role="group" aria-label="Worlds. Tap or drag one world onto another to toggle accessibility."></div>
    <p class="hint">Tap a world, then another (or drag) to toggle R. Tap P / Q inside a world to flip its truth.</p>
    <p id="facts" class="facts"></p>
  </section>

  <aside class="panel" aria-label="Logic symbols">
    <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('groups'), 'g');
$_smarty_tpl->getVariable('g')->index = -1;
$foreach2DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('g')->value) {
$foreach2DoElse = false;
$_smarty_tpl->getVariable('g')->index++;
$_smarty_tpl->getVariable('g')->first = !$_smarty_tpl->getVariable('g')->index;
$foreach2Backup = clone $_smarty_tpl->getVariable('g');
?>
    <details<?php if ($_smarty_tpl->getVariable('g')->first) {?> open<?php }?>>
      <summary><?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('g')['title']), ENT_QUOTES, 'UTF-8');?>
 <small><?php echo htmlspecialchars((string) ($_smarty_tpl->getSmarty()->getModifierCallback('count')($_smarty_tpl->getValue('g')['items'])), ENT_QUOTES, 'UTF-8');?>
</small></summary>
      <dl>
        <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('g')['items'], 'i');
$foreach3DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('i')->value) {
$foreach3DoElse = false;
?>
        <div class="sym" role="button" tabindex="0" data-s="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('i')['sym']), ENT_QUOTES, 'UTF-8');?>
" data-k="<?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('i')['sym']), ENT_QUOTES, 'UTF-8');?>
 <?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('i')['name']), ENT_QUOTES, 'UTF-8');?>
 <?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('i')['read']), ENT_QUOTES, 'UTF-8');?>
">
          <dt><?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('i')['sym']), ENT_QUOTES, 'UTF-8');?>
</dt><dd><b><?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('i')['name']), ENT_QUOTES, 'UTF-8');?>
</b> <?php echo htmlspecialchars((string) ($_smarty_tpl->getValue('i')['read']), ENT_QUOTES, 'UTF-8');?>
</dd>
        </div>
        <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
      </dl>
    </details>
    <?php
$_smarty_tpl->setVariable('g', $foreach2Backup);
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
  </aside>
</main>
<?php echo '<script'; ?>
 type="application/json" id="seed"><?php echo $_smarty_tpl->getValue('seed');
echo '</script'; ?>
>
</body>
</html>
<?php }
}
