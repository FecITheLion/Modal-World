<?php
/* Smarty version 5.8.5, created on 2026-10-17 23:11:15
  from 'file:mosaic.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCached()->isFresh($_smarty_tpl, array (
  'version' => '5.8.5',
  'unifunc' => 'content_6ad3e4730c9d04_99035152',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2fcb13e78dc70fec765f3b68c3b539944522e95a' => 
    array (
      0 => 'mosaic.tpl',
      1 => 1792265943,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 300,
))) {
function content_6ad3e4730c9d04_99035152 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\Modal\\templates';
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Modal worlds mosaic</title>
<link rel="stylesheet" href="/Modal/public/app.css">
<script src="/Modal/public/wasm.js" defer></script>
<script src="/Modal/public/app.js" defer></script>
</head>
<body>
<header class="bar">
  <h1>Modal worlds</h1>
  <label class="find">Find or build with a symbol
    <input id="q" list="symbols" autocomplete="off" spellcheck="false" placeholder="□  ◇  K  U  …">
  </label>
  <datalist id="symbols"><option value="¬" label="negation"><option value="∧" label="conjunction"><option value="∨" label="disjunction"><option value="→" label="implication"><option value="↔" label="biconditional"><option value="⊕" label="exclusive or"><option value="↑" label="NAND (Sheffer)"><option value="↓" label="NOR (Peirce)"><option value="⊤" label="verum"><option value="⊥" label="falsum"><option value="≡" label="equivalence"><option value="□" label="necessity"><option value="◇" label="possibility"><option value="⇒" label="strict implication"><option value="Δ" label="non-contingency"><option value="∇" label="contingency"><option value="⟨a⟩" label="diamond (action a)"><option value="[a]" label="box (action a)"><option value="R" label="accessibility"><option value="W" label="set of worlds"><option value="V" label="valuation"><option value="⊩" label="forces"><option value="⊨" label="entails"><option value="⊭" label="does not entail"><option value="⊢" label="proves"><option value="⊬" label="does not prove"><option value="⟦P⟧" label="extension"><option value="∈" label="member of"><option value="⊆" label="subset"><option value="∩" label="intersection"><option value="∪" label="union"><option value="" label=""><option value="" label="empty set"><option value="∀" label="for all"><option value="∃" label="exists"><option value="∃!" label="exists exactly one"><option value="=" label="identity"><option value="≠" label="distinctness"><option value="λ" label="lambda"><option value="ι" label="definite description"><option value="K" label="knows"><option value="B" label="believes"><option value="E" label="everyone knows"><option value="C" label="common knowledge"><option value="D" label="distributed knowledge"><option value="[!P]" label="public announcement"><option value="O" label="obligatory"><option value="P" label="permitted"><option value="F" label="forbidden"><option value="G" label="always (future)"><option value="F" label="eventually"><option value="X" label="next"><option value="U" label="until"><option value="R" label="release"><option value="W" label="weak until"><option value="H" label="always (past)"><option value="S" label="since"><option value="A" label="all paths"><option value="E" label="some path"><option value=";" label="sequence"><option value="*" label="iteration"><option value="?" label="test"><option value="μ" label="least fixpoint"><option value="ν" label="greatest fixpoint"><option value="∴" label="therefore"><option value="∵" label="because"><option value="∎" label="end of proof"></datalist>
  <span class="grow"></span>
  <span id="engine" class="chip" title="Engine computing □, ◇ and closures">…</span>
  <a class="btn" id="login" href="/Modal/public/auth/login?id=github" rel="nofollow">Sign in</a>
  <span id="who" class="chip" hidden>signed in</span>
</header>

<main class="layout">
  <section class="panel" aria-label="Worlds">
    <div class="tools" role="toolbar" aria-label="Frame tools">
      <button type="button" data-act="add">+ world</button>
      <button type="button" data-act="atom" aria-pressed="false">atom: <b id="atomName">P</b></button>
      <span class="grow"></span>
      <button type="button" data-sys="D" title="serial">D</button>
      <button type="button" data-sys="T" title="reflexive">T</button>
      <button type="button" data-sys="B" title="reflexive + symmetric">B</button>
      <button type="button" data-sys="S4" title="reflexive + transitive">S4</button>
      <button type="button" data-sys="S5" title="equivalence relation">S5</button>
      <button type="button" data-act="clear">clear R</button>
    </div>
    <div id="mosaic" class="mosaic" role="group" aria-label="Worlds. Tap or drag one world onto another to toggle accessibility."></div>
    <p class="hint">Tap a world, then another (or drag) to toggle R. Tap P / Q inside a world to flip its truth.</p>
    <p id="facts" class="facts"></p>
  </section>

  <aside class="panel" aria-label="Logic symbols">
        <details open>
      <summary>Propositional <small>11</small></summary>
      <dl>
                <div class="sym" role="button" tabindex="0" data-s="¬" data-k="¬ negation not P: true at w iff P is false at w">
          <dt>¬</dt><dd><b>negation</b> not P: true at w iff P is false at w</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="∧" data-k="∧ conjunction P and Q both true at w">
          <dt>∧</dt><dd><b>conjunction</b> P and Q both true at w</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="∨" data-k="∨ disjunction at least one of P, Q true at w">
          <dt>∨</dt><dd><b>disjunction</b> at least one of P, Q true at w</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="→" data-k="→ implication if P then Q at w">
          <dt>→</dt><dd><b>implication</b> if P then Q at w</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="↔" data-k="↔ biconditional P and Q have the same truth value at w">
          <dt>↔</dt><dd><b>biconditional</b> P and Q have the same truth value at w</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="⊕" data-k="⊕ exclusive or exactly one of P, Q is true">
          <dt>⊕</dt><dd><b>exclusive or</b> exactly one of P, Q is true</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="↑" data-k="↑ NAND (Sheffer) not both P and Q">
          <dt>↑</dt><dd><b>NAND (Sheffer)</b> not both P and Q</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="↓" data-k="↓ NOR (Peirce) neither P nor Q">
          <dt>↓</dt><dd><b>NOR (Peirce)</b> neither P nor Q</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="⊤" data-k="⊤ verum true at every world">
          <dt>⊤</dt><dd><b>verum</b> true at every world</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="⊥" data-k="⊥ falsum true at no world">
          <dt>⊥</dt><dd><b>falsum</b> true at no world</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="≡" data-k="≡ equivalence true at exactly the same worlds">
          <dt>≡</dt><dd><b>equivalence</b> true at exactly the same worlds</dd>
        </div>
              </dl>
    </details>
        <details>
      <summary>Alethic modal <small>7</small></summary>
      <dl>
                <div class="sym" role="button" tabindex="0" data-s="□" data-k="□ necessity P at every accessible world">
          <dt>□</dt><dd><b>necessity</b> P at every accessible world</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="◇" data-k="◇ possibility P at some accessible world">
          <dt>◇</dt><dd><b>possibility</b> P at some accessible world</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="⇒" data-k="⇒ strict implication □(P → Q)">
          <dt>⇒</dt><dd><b>strict implication</b> □(P → Q)</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="Δ" data-k="Δ non-contingency □P ∨ □¬P">
          <dt>Δ</dt><dd><b>non-contingency</b> □P ∨ □¬P</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="∇" data-k="∇ contingency ◇P ∧ ◇¬P">
          <dt>∇</dt><dd><b>contingency</b> ◇P ∧ ◇¬P</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="⟨a⟩" data-k="⟨a⟩ diamond (action a) some a-successor satisfies P">
          <dt>⟨a⟩</dt><dd><b>diamond (action a)</b> some a-successor satisfies P</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="[a]" data-k="[a] box (action a) every a-successor satisfies P">
          <dt>[a]</dt><dd><b>box (action a)</b> every a-successor satisfies P</dd>
        </div>
              </dl>
    </details>
        <details>
      <summary>Frames and models <small>15</small></summary>
      <dl>
                <div class="sym" role="button" tabindex="0" data-s="R" data-k="R accessibility wRv: v is possible relative to w">
          <dt>R</dt><dd><b>accessibility</b> wRv: v is possible relative to w</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="W" data-k="W set of worlds the domain of the model">
          <dt>W</dt><dd><b>set of worlds</b> the domain of the model</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="V" data-k="V valuation assigns atoms to the worlds where they hold">
          <dt>V</dt><dd><b>valuation</b> assigns atoms to the worlds where they hold</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="⊩" data-k="⊩ forces w ⊩ P: P holds at w">
          <dt>⊩</dt><dd><b>forces</b> w ⊩ P: P holds at w</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="⊨" data-k="⊨ entails truth in a model; semantic consequence">
          <dt>⊨</dt><dd><b>entails</b> truth in a model; semantic consequence</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="⊭" data-k="⊭ does not entail P fails in some model or world">
          <dt>⊭</dt><dd><b>does not entail</b> P fails in some model or world</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="⊢" data-k="⊢ proves derivable in the system">
          <dt>⊢</dt><dd><b>proves</b> derivable in the system</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="⊬" data-k="⊬ does not prove not derivable">
          <dt>⊬</dt><dd><b>does not prove</b> not derivable</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="⟦P⟧" data-k="⟦P⟧ extension the set of worlds where P holds">
          <dt>⟦P⟧</dt><dd><b>extension</b> the set of worlds where P holds</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="∈" data-k="∈ member of w ∈ W">
          <dt>∈</dt><dd><b>member of</b> w ∈ W</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="⊆" data-k="⊆ subset every world of one set is in the other">
          <dt>⊆</dt><dd><b>subset</b> every world of one set is in the other</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="∩" data-k="∩ intersection worlds in both extensions">
          <dt>∩</dt><dd><b>intersection</b> worlds in both extensions</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="∪" data-k="∪ union worlds in either extension">
          <dt>∪</dt><dd><b>union</b> worlds in either extension</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="" data-k="  ">
          <dt></dt><dd><b></b> </dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="" data-k=" empty set no worlds">
          <dt></dt><dd><b>empty set</b> no worlds</dd>
        </div>
              </dl>
    </details>
        <details>
      <summary>Quantifiers and identity <small>7</small></summary>
      <dl>
                <div class="sym" role="button" tabindex="0" data-s="∀" data-k="∀ for all every individual (or world) in the domain">
          <dt>∀</dt><dd><b>for all</b> every individual (or world) in the domain</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="∃" data-k="∃ exists some individual in the domain">
          <dt>∃</dt><dd><b>exists</b> some individual in the domain</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="∃!" data-k="∃! exists exactly one a unique individual">
          <dt>∃!</dt><dd><b>exists exactly one</b> a unique individual</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="=" data-k="= identity the same individual across worlds">
          <dt>=</dt><dd><b>identity</b> the same individual across worlds</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="≠" data-k="≠ distinctness not the same individual">
          <dt>≠</dt><dd><b>distinctness</b> not the same individual</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="λ" data-k="λ lambda abstracts a property from a formula">
          <dt>λ</dt><dd><b>lambda</b> abstracts a property from a formula</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="ι" data-k="ι definite description the unique individual such that">
          <dt>ι</dt><dd><b>definite description</b> the unique individual such that</dd>
        </div>
              </dl>
    </details>
        <details>
      <summary>Epistemic <small>6</small></summary>
      <dl>
                <div class="sym" role="button" tabindex="0" data-s="K" data-k="K knows Kₐ P: agent a knows P (P at all worlds a considers possible)">
          <dt>K</dt><dd><b>knows</b> Kₐ P: agent a knows P (P at all worlds a considers possible)</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="B" data-k="B believes Bₐ P: agent a believes P">
          <dt>B</dt><dd><b>believes</b> Bₐ P: agent a believes P</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="E" data-k="E everyone knows every agent in the group knows P">
          <dt>E</dt><dd><b>everyone knows</b> every agent in the group knows P</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="C" data-k="C common knowledge everyone knows that everyone knows, without end">
          <dt>C</dt><dd><b>common knowledge</b> everyone knows that everyone knows, without end</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="D" data-k="D distributed knowledge what the group knows by pooling">
          <dt>D</dt><dd><b>distributed knowledge</b> what the group knows by pooling</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="[!P]" data-k="[!P] public announcement after P is announced truthfully">
          <dt>[!P]</dt><dd><b>public announcement</b> after P is announced truthfully</dd>
        </div>
              </dl>
    </details>
        <details>
      <summary>Deontic <small>3</small></summary>
      <dl>
                <div class="sym" role="button" tabindex="0" data-s="O" data-k="O obligatory P at every ideal world">
          <dt>O</dt><dd><b>obligatory</b> P at every ideal world</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="P" data-k="P permitted P at some ideal world">
          <dt>P</dt><dd><b>permitted</b> P at some ideal world</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="F" data-k="F forbidden O¬P">
          <dt>F</dt><dd><b>forbidden</b> O¬P</dd>
        </div>
              </dl>
    </details>
        <details>
      <summary>Temporal <small>10</small></summary>
      <dl>
                <div class="sym" role="button" tabindex="0" data-s="G" data-k="G always (future) P at all later times">
          <dt>G</dt><dd><b>always (future)</b> P at all later times</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="F" data-k="F eventually P at some later time">
          <dt>F</dt><dd><b>eventually</b> P at some later time</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="X" data-k="X next P at the next step">
          <dt>X</dt><dd><b>next</b> P at the next step</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="U" data-k="U until P holds until Q does">
          <dt>U</dt><dd><b>until</b> P holds until Q does</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="R" data-k="R release Q holds until and including when P does">
          <dt>R</dt><dd><b>release</b> Q holds until and including when P does</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="W" data-k="W weak until U, or P forever">
          <dt>W</dt><dd><b>weak until</b> U, or P forever</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="H" data-k="H always (past) P at all earlier times">
          <dt>H</dt><dd><b>always (past)</b> P at all earlier times</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="S" data-k="S since Q held since P">
          <dt>S</dt><dd><b>since</b> Q held since P</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="A" data-k="A all paths on every branch (CTL)">
          <dt>A</dt><dd><b>all paths</b> on every branch (CTL)</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="E" data-k="E some path on some branch (CTL)">
          <dt>E</dt><dd><b>some path</b> on some branch (CTL)</dd>
        </div>
              </dl>
    </details>
        <details>
      <summary>Dynamic and fixpoint <small>5</small></summary>
      <dl>
                <div class="sym" role="button" tabindex="0" data-s=";" data-k="; sequence do a, then b">
          <dt>;</dt><dd><b>sequence</b> do a, then b</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="*" data-k="* iteration repeat zero or more times">
          <dt>*</dt><dd><b>iteration</b> repeat zero or more times</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="?" data-k="? test continue only if P holds">
          <dt>?</dt><dd><b>test</b> continue only if P holds</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="μ" data-k="μ least fixpoint smallest set closed under the formula">
          <dt>μ</dt><dd><b>least fixpoint</b> smallest set closed under the formula</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="ν" data-k="ν greatest fixpoint largest set consistent with the formula">
          <dt>ν</dt><dd><b>greatest fixpoint</b> largest set consistent with the formula</dd>
        </div>
              </dl>
    </details>
        <details>
      <summary>Proof marks <small>3</small></summary>
      <dl>
                <div class="sym" role="button" tabindex="0" data-s="∴" data-k="∴ therefore conclusion follows">
          <dt>∴</dt><dd><b>therefore</b> conclusion follows</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="∵" data-k="∵ because reason given">
          <dt>∵</dt><dd><b>because</b> reason given</dd>
        </div>
                <div class="sym" role="button" tabindex="0" data-s="∎" data-k="∎ end of proof Q.E.D.">
          <dt>∎</dt><dd><b>end of proof</b> Q.E.D.</dd>
        </div>
              </dl>
    </details>
      </aside>
</main>
<script type="application/json" id="seed">{"worlds":[{"id":"w0","P":true,"Q":true},{"id":"w1","P":true,"Q":false},{"id":"w2","P":true,"Q":true}],"relation":[["w0","w1"],["w0","w2"],["w1","w2"]],"frame":{"reflexive":false,"serial":false,"symmetric":false,"transitive":true,"euclidean":false}}</script>
</body>
</html>
<?php }
}
