<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Modal worlds mosaic</title>
<link rel="stylesheet" href="{$base}/app.css">
<script src="{$base}/wasm.js" defer></script>
<script src="{$base}/app.js" defer></script>
</head>
<body>
<header class="bar">
  <h1>Modal worlds</h1>
  <label class="find">Find or build with a symbol
    <input id="q" list="symbols" autocomplete="off" spellcheck="false" placeholder="□  ◇  K  U  …">
  </label>
  <datalist id="symbols">{foreach $groups as $g}{foreach $g.items as $i}<option value="{$i.sym}" label="{$i.name}">{/foreach}{/foreach}</datalist>
  <span class="grow"></span>
  <span id="engine" class="chip" title="Engine computing □, ◇ and closures">…</span>
  <a class="btn" id="login" href="{$base}/auth/login?id={$provider|escape:'url'}" rel="nofollow">Sign in</a>
  <span id="who" class="chip" hidden>signed in</span>
</header>

<main class="layout">
  <section class="panel" aria-label="Worlds">
    <div class="tools" role="toolbar" aria-label="Frame tools">
      <button type="button" data-act="add">+ world</button>
      <button type="button" data-act="atom" aria-pressed="false">atom: <b id="atomName">P</b></button>
      <span class="grow"></span>
      <button type="button" data-sys="D" title="serial">D</button>
      <button type="button" data-sys="T" title="reflexive">T</button>
      <button type="button" data-sys="B" title="reflexive + symmetric">B</button>
      <button type="button" data-sys="S4" title="reflexive + transitive">S4</button>
      <button type="button" data-sys="S5" title="equivalence relation">S5</button>
      <button type="button" data-act="clear">clear R</button>
    </div>
    <div id="mosaic" class="mosaic" role="group" aria-label="Worlds. Tap or drag one world onto another to toggle accessibility."></div>
    <p class="hint">Tap a world, then another (or drag) to toggle R. Tap P / Q inside a world to flip its truth.</p>
    <p id="facts" class="facts"></p>
  </section>

  <aside class="panel" aria-label="Logic symbols">
    {foreach $groups as $g}
    <details{if $g@first} open{/if}>
      <summary>{$g.title} <small>{$g.items|count}</small></summary>
      <dl>
        {foreach $g.items as $i}
        <div class="sym" role="button" tabindex="0" data-s="{$i.sym}" data-k="{$i.sym} {$i.name} {$i.read}">
          <dt>{$i.sym}</dt><dd><b>{$i.name}</b> {$i.read}</dd>
        </div>
        {/foreach}
      </dl>
    </details>
    {/foreach}
  </aside>
</main>
<script type="application/json" id="seed">{$seed nofilter}</script>
</body>
</html>
