-- The only table. JSON-LD (schema/oauth-login.context.jsonld) defines the shape; Snowflake stores the JSON.
CREATE TABLE IF NOT EXISTS OAUTH_LOGIN_INSTRUCTIONS (
  ID         STRING PRIMARY KEY,
  DOC        VARIANT NOT NULL,
  UPDATED_AT TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);
INSERT INTO OAUTH_LOGIN_INSTRUCTIONS (ID, DOC)
SELECT 'github', PARSE_JSON('{
  "@context": "https://www.cmdr.site/Modal/public/schema/oauth",
  "@type": "OAuthLoginInstructions",
  "@id": "urn:oauth:github",
  "authorizationEndpoint": "https://github.com/login/oauth/authorize",
  "tokenEndpoint": "https://github.com/login/oauth/access_token",
  "redirectUri": "https://www.cmdr.site/Modal/public/auth/callback",
  "clientId": "YOUR_CLIENT_ID",
  "clientSecretEnv": "GITHUB_CLIENT_SECRET",
  "scope": ["read:user"],
  "pkce": "S256"
}');
