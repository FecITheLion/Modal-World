<?php
declare(strict_types=1);
namespace ModalApp;

/** Smarty wrapper (works with Smarty 5 and 4). Compiled templates and rendered output are cached on disk. */
final class View
{
    private $smarty;

    public function __construct(string $root)
    {
        $cls = class_exists('Smarty\\Smarty') ? 'Smarty\\Smarty' : 'Smarty';
        $this->smarty = new $cls();
        $this->smarty->setTemplateDir($root . '/templates')
            ->setCompileDir($root . '/var/compile')
            ->setCacheDir($root . '/var/cache');
        $this->smarty->setCaching(1);                 // CACHING_LIFETIME_CURRENT
        $this->smarty->setCacheLifetime(300);
        $this->smarty->setEscapeHtml(true);           // everything escaped unless marked nofilter
    }

    public function render(string $tpl, array $vars, string $cacheId): string
    {
        if (!$this->smarty->isCached($tpl, $cacheId)) {
            foreach ($vars as $k => $v) {
                $this->smarty->assign($k, $v);
            }
        }
        return $this->smarty->fetch($tpl, $cacheId);
    }
}
