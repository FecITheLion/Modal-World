<?php
declare(strict_types=1);
namespace ModalApp;

/** Accept-header negotiation (q-values, type/*, . Offers are in server-preference order. */
final class Negotiator
{
    public static function best(string $accept, array $offers): ?string
    {
        $ranges = [];
        foreach (explode(',', $accept === '' ? '*/*' : $accept) as $part) {
            $bits = array_map('trim', explode(';', trim($part)));
            $type = strtolower((string) array_shift($bits));
            $q = 1.0;
            foreach ($bits as $b) {
                if (stripos($b, 'q=') === 0) {
                    $q = (float) substr($b, 2);
                }
            }
            if ($type !== '') {
                $ranges[] = [$type, $q];
            }
        }
        $best = null;
        $bestQ = 0.0;
        foreach ($offers as $offer) {
            $q = 0.0;
            $spec = -1;
            foreach ($ranges as $r) {
                $s = $r[0] === $offer ? 2 : ($r[0] === strtok($offer, '/') . '/*' ? 1 : ($r[0] === '*/*' ? 0 : -1));
                if ($s > $spec) {
                    $spec = $s;
                    $q = $r[1];
                }
            }
            if ($spec >= 0 && $q > $bestQ) {
                $best = $offer;
                $bestQ = $q;
            }
        }
        return $best;
    }
}

/** Output-buffered, negotiated, ETag'd, compressed responses. Never sets a cookie. */
final class Respond
{
    /**
     * @param array<string,callable> $variants mime => producer (echoes and/or returns the body)
     */
    public static function negotiate(array $variants, string $cache = 'public, max-age=60, stale-while-revalidate=300'): void
    {
        header_remove('Set-Cookie');
        header('Vary: Accept, Accept-Encoding');
        $mime = Negotiator::best($_SERVER['HTTP_ACCEPT'] ?? '*/*', array_keys($variants));
        if ($mime === null) {
            http_response_code(406);
            header('Content-Type: text/plain; charset=utf-8');
            echo "406 Not Acceptable. Offered: " . implode(', ', array_keys($variants));
            return;
        }

        ob_start();                                   // OB: capture whatever the producer prints
        try {
            $ret = $variants[$mime]();
        } catch (\Throwable $e) {
            ob_end_clean();
            throw $e;
        }
        $body = ob_get_clean() . (is_string($ret) ? $ret : '');

        $text = (bool) preg_match('~^(text/|application/(ld\+)?json|image/svg\+xml)~', $mime);
        $ae = $_SERVER['HTTP_ACCEPT_ENCODING'] ?? '';
        $enc = '';
        if ($text && strlen($body) > 512) {
            if (function_exists('brotli_compress') && preg_match('~\bbr\b~', $ae)) {
                $enc = 'br';
            } elseif (function_exists('gzencode') && preg_match('~\bgzip\b~', $ae)) {
                $enc = 'gzip';
            }
        }

        $etag = '"' . substr(sha1($mime . "\0" . $body), 0, 32) . ($enc !== '' ? '-' . $enc : '') . '"';
        header('ETag: ' . $etag);
        header('Cache-Control: ' . $cache);
        header('X-Content-Type-Options: nosniff');

        foreach (explode(',', $_SERVER['HTTP_IF_NONE_MATCH'] ?? '') as $t) {
            $t = preg_replace('~^W/~', '', trim($t));
            if ($t !== '' && ($t === '*' || $t === $etag)) {
                http_response_code(304);
                return;                               // validators matched: no body, no compression work
            }
        }

        if ($enc === 'br') {
            $body = brotli_compress($body);
        } elseif ($enc === 'gzip') {
            $body = gzencode($body, 6);
        }
        header('Content-Type: ' . $mime . ($text ? '; charset=utf-8' : ''));
        if ($enc !== '') {
            header('Content-Encoding: ' . $enc);
        }
        header('Content-Length: ' . strlen($body));
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'HEAD') {
            echo $body;
        }
    }

    public static function text(int $status, string $msg): void
    {
        header_remove('Set-Cookie');
        http_response_code($status);
        header('Content-Type: text/plain; charset=utf-8');
        header('Cache-Control: no-store');
        echo $msg;
    }
}
