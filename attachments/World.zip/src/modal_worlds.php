<?php

declare(strict_types=1);

/**
 * Possible-worlds (Kripke) semantics for propositional modal logic.  PHP 7.4+
 *
 *   ModalWorldObject  one world: an id plus a valuation (which atoms are true there)
 *   ModalWorlds       a Kripke model: worlds + accessibility relation R + actual world
 *   Formula           Atom, Not, Conjunction, Disjunction, Implication, Biconditional,
 *                     Box (□), Diamond (◇), and Named (made with Formula::let)
 *   ModalSystem       K, D, T, B, S4, S5 as frame conditions, plus the classic axioms
 *   NecessityType     logical / physical / metaphysical necessity
 *   ModalAssertions   checks on a model or frame, throwing AssertionFailed or collecting a report
 *
 * Run it from the command line to see the demo:  php modal_worlds.php
 */

namespace ModalLogic;

use ArrayIterator;
use Countable;
use InvalidArgumentException;
use IteratorAggregate;
use OutOfBoundsException;
use RuntimeException;
use Traversable;

/* ------------------------------------------------------------------------ *
 * Worlds
 * ------------------------------------------------------------------------ */

final class ModalWorldObject
{
    private string $id;
    private string $label;
    private string $description;

    /** @var array<string,bool> atom => truth value */
    private array $truths = [];

    /** @var array<string,mixed> free-form data (e.g. which laws of physics hold here) */
    private array $meta = [];

    /**
     * @param array $truths  ['P', 'Q'] (those atoms are true) or ['P' => true, 'Q' => false]
     */
    public function __construct(
        string $id,
        array $truths = [],
        string $label = '',
        string $description = '',
        array $meta = []
    ) {
        if ($id === '') {
            throw new InvalidArgumentException('A world needs a non-empty id.');
        }
        $this->id          = $id;
        $this->label       = $label !== '' ? $label : $id;
        $this->description = $description;
        $this->meta        = $meta;

        foreach ($truths as $key => $value) {
            if (is_int($key)) {
                $this->assign((string) $value, true);
            } else {
                $this->assign((string) $key, (bool) $value);
            }
        }
    }

    public function id(): string
    {
        return $this->id;
    }

    public function label(): string
    {
        return $this->label;
    }

    public function description(): string
    {
        return $this->description;
    }

    /** Set an atom's truth value at this world. */
    public function assign(string $atom, bool $value = true): self
    {
        $this->truths[$atom] = $value;
        return $this;
    }

    /** Atoms never assigned are treated as false here. */
    public function holds(string $atom): bool
    {
        return $this->truths[$atom] ?? false;
    }

    /** @return array<string,bool> */
    public function truths(): array
    {
        return $this->truths;
    }

    /** @return string[] */
    public function trueAtoms(): array
    {
        return array_map('strval', array_keys(array_filter($this->truths)));
    }

    /** @return string[] every atom this world has an explicit value for */
    public function knownAtoms(): array
    {
        return array_map('strval', array_keys($this->truths));
    }

    /** @return mixed */
    public function meta(string $key, $default = null)
    {
        return array_key_exists($key, $this->meta) ? $this->meta[$key] : $default;
    }

    public function withMeta(string $key, $value): self
    {
        $this->meta[$key] = $value;
        return $this;
    }

    /** e.g. "P, ¬Q" for the given atoms. */
    public function literals(array $atoms): string
    {
        $parts = [];
        foreach ($atoms as $atom) {
            $parts[] = $this->holds($atom) ? $atom : '¬' . $atom;
        }
        return implode(', ', $parts);
    }

    public function __toString(): string
    {
        return $this->label === $this->id ? $this->id : "{$this->id} ({$this->label})";
    }
}

/* ------------------------------------------------------------------------ *
 * Formulas
 * ------------------------------------------------------------------------ */

abstract class Formula
{
    /** Truth of this formula at one world of a model. */
    abstract public function holdsAt(ModalWorlds $model, string $worldId): bool;

    /** @return string[] the atoms mentioned, without duplicates */
    abstract public function atoms(): array;

    /** Plain-English reading, e.g. "it is necessary that P". */
    abstract public function english(): string;

    /** Text form; with $unfold = true every let-bound name is replaced by its definition. */
    abstract public function render(bool $unfold = false): string;

    public function unfold(): string
    {
        return $this->render(true);
    }

    public function __toString(): string
    {
        return $this->render(false);
    }

    /** The formula with any let-name stripped off (so ◇/□ can be recognised). */
    public function core(): Formula
    {
        return $this;
    }

    /**
     * For □ the accessible worlds that refute it, for ◇ the accessible worlds that
     * support it. Every other formula has no witnesses.
     *
     * @return string[]
     */
    public function witnesses(ModalWorlds $model, string $worldId): array
    {
        return [];
    }

    /* Fluent builders: Formula::atom('P')->box()->implies(Formula::atom('P')) */

    public static function atom(string $name): Atom
    {
        return new Atom($name);
    }

    public function neg(): Not
    {
        return new Not($this);
    }

    public function conj(Formula $other): Conjunction
    {
        return new Conjunction($this, $other);
    }

    public function disj(Formula $other): Disjunction
    {
        return new Disjunction($this, $other);
    }

    public function implies(Formula $other): Implication
    {
        return new Implication($this, $other);
    }

    public function box(): Box
    {
        return new Box($this);
    }

    public function diamond(): Diamond
    {
        return new Diamond($this);
    }

    public function iff(Formula $other): Biconditional
    {
        return new Biconditional($this, $other);
    }

    /**
     * let $name := $bound in $body.
     *
     * The body receives the bound formula as a Named node, so it can use it as many times
     * as it likes. Scoping is lexical (the closure decides what is visible), and nested
     * lets can shadow each other without any surprises:
     *
     *   Formula::let('Safe', $p->box(), function (Formula $safe) {
     *       return $safe->implies($safe->diamond());
     *   });
     *
     * @param callable(Formula):Formula $body
     */
    public static function let(string $name, Formula $bound, callable $body): Formula
    {
        $result = $body(new Named($name, $bound));
        if (!$result instanceof Formula) {
            throw new InvalidArgumentException("The body of let '$name' must return a Formula.");
        }
        return $result;
    }
}

final class Atom extends Formula
{
    private string $name;

    public function __construct(string $name)
    {
        if ($name === '') {
            throw new InvalidArgumentException('An atom needs a non-empty name.');
        }
        $this->name = $name;
    }

    public function name(): string
    {
        return $this->name;
    }

    public function holdsAt(ModalWorlds $model, string $worldId): bool
    {
        return $model->world($worldId)->holds($this->name);
    }

    public function atoms(): array
    {
        return [$this->name];
    }

    public function english(): string
    {
        return $this->name;
    }

    public function render(bool $unfold = false): string
    {
        return $this->name;
    }
}

abstract class UnaryFormula extends Formula
{
    protected Formula $operand;

    public function __construct(Formula $operand)
    {
        $this->operand = $operand;
    }

    public function operand(): Formula
    {
        return $this->operand;
    }

    abstract protected function symbol(): string;

    abstract protected function reading(): string;

    public function atoms(): array
    {
        return $this->operand->atoms();
    }

    public function english(): string
    {
        return $this->reading() . ' ' . $this->operand->english();
    }

    public function render(bool $unfold = false): string
    {
        return $this->symbol() . $this->operand->render($unfold);
    }
}

abstract class BinaryFormula extends Formula
{
    protected Formula $left;
    protected Formula $right;

    public function __construct(Formula $left, Formula $right)
    {
        $this->left  = $left;
        $this->right = $right;
    }

    abstract protected function symbol(): string;

    abstract protected function word(): string;

    public function atoms(): array
    {
        return array_values(array_unique(array_merge($this->left->atoms(), $this->right->atoms())));
    }

    public function english(): string
    {
        return '(' . $this->left->english() . ' ' . $this->word() . ' ' . $this->right->english() . ')';
    }

    public function render(bool $unfold = false): string
    {
        return '(' . $this->left->render($unfold) . ' ' . $this->symbol() . ' '
             . $this->right->render($unfold) . ')';
    }
}

final class Not extends UnaryFormula
{
    protected function symbol(): string
    {
        return '¬';
    }

    protected function reading(): string
    {
        return 'it is not the case that';
    }

    public function holdsAt(ModalWorlds $model, string $worldId): bool
    {
        return !$this->operand->holdsAt($model, $worldId);
    }
}

final class Conjunction extends BinaryFormula
{
    protected function symbol(): string
    {
        return '∧';
    }

    protected function word(): string
    {
        return 'and';
    }

    public function holdsAt(ModalWorlds $model, string $worldId): bool
    {
        return $this->left->holdsAt($model, $worldId) && $this->right->holdsAt($model, $worldId);
    }
}

final class Disjunction extends BinaryFormula
{
    protected function symbol(): string
    {
        return '∨';
    }

    protected function word(): string
    {
        return 'or';
    }

    public function holdsAt(ModalWorlds $model, string $worldId): bool
    {
        return $this->left->holdsAt($model, $worldId) || $this->right->holdsAt($model, $worldId);
    }
}

final class Implication extends BinaryFormula
{
    protected function symbol(): string
    {
        return '→';
    }

    protected function word(): string
    {
        return 'implies';
    }

    public function holdsAt(ModalWorlds $model, string $worldId): bool
    {
        return !$this->left->holdsAt($model, $worldId) || $this->right->holdsAt($model, $worldId);
    }
}

final class Biconditional extends BinaryFormula
{
    protected function symbol(): string
    {
        return '↔';
    }

    protected function word(): string
    {
        return 'if and only if';
    }

    public function holdsAt(ModalWorlds $model, string $worldId): bool
    {
        return $this->left->holdsAt($model, $worldId) === $this->right->holdsAt($model, $worldId);
    }
}

/**
 * A formula with a name, created by Formula::let(). It prints as its name, behaves exactly
 * like its definition, and can be expanded with unfold().
 */
final class Named extends Formula
{
    private string $name;
    private Formula $definition;

    public function __construct(string $name, Formula $definition)
    {
        if ($name === '') {
            throw new InvalidArgumentException('A let-bound name must not be empty.');
        }
        $this->name       = $name;
        $this->definition = $definition;
    }

    public function name(): string
    {
        return $this->name;
    }

    public function definition(): Formula
    {
        return $this->definition;
    }

    /** e.g. "Safe := □P" */
    public function binding(): string
    {
        return $this->name . ' := ' . $this->definition->render(true);
    }

    public function holdsAt(ModalWorlds $model, string $worldId): bool
    {
        return $this->definition->holdsAt($model, $worldId);
    }

    public function atoms(): array
    {
        return $this->definition->atoms();
    }

    public function english(): string
    {
        return $this->definition->english();
    }

    public function render(bool $unfold = false): string
    {
        return $unfold ? $this->definition->render(true) : $this->name;
    }

    public function core(): Formula
    {
        return $this->definition->core();
    }

    public function witnesses(ModalWorlds $model, string $worldId): array
    {
        return $this->definition->witnesses($model, $worldId);
    }
}

/** □P — P is true at every world accessible from the evaluation world. */
final class Box extends UnaryFormula
{
    public const NAME    = 'box';
    public const SYMBOL  = '□';
    public const READING = 'it is necessary that';
    public const MEANING = 'P holds true across all accessible possible worlds';

    protected function symbol(): string
    {
        return self::SYMBOL;
    }

    protected function reading(): string
    {
        return self::READING;
    }

    /** Vacuously true when no world is accessible. */
    public function holdsAt(ModalWorlds $model, string $worldId): bool
    {
        foreach ($model->accessibleFrom($worldId) as $other) {
            if (!$this->operand->holdsAt($model, $other)) {
                return false;
            }
        }
        return true;
    }

    /** Accessible worlds where the operand fails (counterexamples to □). */
    public function witnesses(ModalWorlds $model, string $worldId): array
    {
        return array_values(array_filter(
            $model->accessibleFrom($worldId),
            function (string $other) use ($model): bool {
                return !$this->operand->holdsAt($model, $other);
            }
        ));
    }
}

/** ◇P — P is true at some world accessible from the evaluation world. */
final class Diamond extends UnaryFormula
{
    public const NAME    = 'diamond';
    public const SYMBOL  = '◇';
    public const READING = 'it is possible that';
    public const MEANING = 'P holds true in at least one accessible possible world';

    protected function symbol(): string
    {
        return self::SYMBOL;
    }

    protected function reading(): string
    {
        return self::READING;
    }

    public function holdsAt(ModalWorlds $model, string $worldId): bool
    {
        foreach ($model->accessibleFrom($worldId) as $other) {
            if ($this->operand->holdsAt($model, $other)) {
                return true;
            }
        }
        return false;
    }

    /** Accessible worlds where the operand holds (witnesses to ◇). */
    public function witnesses(ModalWorlds $model, string $worldId): array
    {
        return array_values(array_filter(
            $model->accessibleFrom($worldId),
            function (string $other) use ($model): bool {
                return $this->operand->holdsAt($model, $other);
            }
        ));
    }
}

/* ------------------------------------------------------------------------ *
 * Systems and kinds of necessity
 * ------------------------------------------------------------------------ */

final class ModalSystem
{
    public const K  = 'K';
    public const D  = 'D';
    public const T  = 'T';
    public const B  = 'B';
    public const S4 = 'S4';
    public const S5 = 'S5';

    /** Frame conditions each system requires of the accessibility relation. */
    private const CONDITIONS = [
        'K'  => [],
        'D'  => ['serial'],
        'T'  => ['reflexive'],
        'B'  => ['reflexive', 'symmetric'],
        'S4' => ['reflexive', 'transitive'],
        'S5' => ['reflexive', 'symmetric', 'transitive'],
    ];

    /** Which frame condition each axiom schema corresponds to (null = holds on every frame). */
    private const AXIOM_CONDITION = [
        'K' => null,
        'D' => 'serial',
        'T' => 'reflexive',
        'B' => 'symmetric',
        '4' => 'transitive',
        '5' => 'euclidean',
    ];

    /** @return string[] */
    public static function names(): array
    {
        return array_keys(self::CONDITIONS);
    }

    /** @return string[] */
    public static function conditions(string $system): array
    {
        $key = strtoupper($system);
        if (!array_key_exists($key, self::CONDITIONS)) {
            throw new InvalidArgumentException(
                "Unknown system '$system'. Known: " . implode(', ', self::names())
            );
        }
        return self::CONDITIONS[$key];
    }

    /**
     * @return string[]
     *
     * strval matters: PHP stores the keys '4' and '5' as integers, and under
     * strict_types an int would be rejected by axiom(string $name).
     */
    public static function axiomNames(): array
    {
        return array_map('strval', array_keys(self::AXIOM_CONDITION));
    }

    public static function axiomCondition(string $axiom): ?string
    {
        if (!array_key_exists($axiom, self::AXIOM_CONDITION)) {
            throw new InvalidArgumentException("Unknown axiom '$axiom'.");
        }
        return self::AXIOM_CONDITION[$axiom];
    }

    /** The axiom schema instantiated with the atoms P and Q. */
    public static function axiom(string $name): Formula
    {
        $p = Formula::atom('P');
        $q = Formula::atom('Q');

        switch ($name) {
            case 'K': // □(P → Q) → (□P → □Q)
                return $p->implies($q)->box()->implies($p->box()->implies($q->box()));
            case 'D': // □P → ◇P
                return $p->box()->implies($p->diamond());
            case 'T': // □P → P
                return $p->box()->implies($p);
            case 'B': // P → □◇P
                return $p->implies($p->diamond()->box());
            case '4': // □P → □□P
                return $p->box()->implies($p->box()->box());
            case '5': // ◇P → □◇P
                return $p->diamond()->implies($p->diamond()->box());
        }
        throw new InvalidArgumentException("Unknown axiom '$name'.");
    }
}

final class NecessityType
{
    public const LOGICAL       = 'logical';
    public const PHYSICAL      = 'physical';
    public const METAPHYSICAL  = 'metaphysical';

    private const DESCRIPTIONS = [
        self::LOGICAL      => 'True in virtue of the laws of logic alone (e.g. P ∨ ¬P). '
                            . 'Modelled by an accessibility relation that links every world.',
        self::PHYSICAL     => 'True given the actual laws of physics of our universe. '
                            . 'Modelled by linking only worlds that share our laws.',
        self::METAPHYSICAL => 'True in virtue of the fundamental nature of reality, '
                            . 'or of what things essentially are (e.g. water is H2O).',
    ];

    /** @return string[] */
    public static function all(): array
    {
        return array_keys(self::DESCRIPTIONS);
    }

    public static function describe(string $type): string
    {
        if (!array_key_exists($type, self::DESCRIPTIONS)) {
            throw new InvalidArgumentException("Unknown necessity type '$type'.");
        }
        return self::DESCRIPTIONS[$type];
    }
}

/* ------------------------------------------------------------------------ *
 * The model
 * ------------------------------------------------------------------------ */

/**
 * A Kripke model M = (W, R, V):
 *   W  the worlds,
 *   R  the accessibility relation (w R v: "v is possible relative to w"),
 *   V  the valuation, stored inside each ModalWorldObject.
 */
final class ModalWorlds implements Countable, IteratorAggregate
{
    /** @var array<string,ModalWorldObject> */
    private array $worlds = [];

    /** @var array<string,array<string,bool>> from-id => [to-id => true] */
    private array $access = [];

    private ?string $actual = null;

    /* ---- worlds ------------------------------------------------------- */

    public function addWorld(ModalWorldObject $world): self
    {
        $id = $world->id();
        if (isset($this->worlds[$id])) {
            throw new InvalidArgumentException("World '$id' already exists.");
        }
        $this->worlds[$id] = $world;
        $this->access[$id] = [];
        if ($this->actual === null) {
            $this->actual = $id;
        }
        return $this;
    }

    public function hasWorld(string $id): bool
    {
        return isset($this->worlds[$id]);
    }

    public function world(string $id): ModalWorldObject
    {
        if (!isset($this->worlds[$id])) {
            throw new OutOfBoundsException("No world '$id' in this model.");
        }
        return $this->worlds[$id];
    }

    /** @return string[] */
    public function ids(): array
    {
        return array_map('strval', array_keys($this->worlds));
    }

    public function count(): int
    {
        return count($this->worlds);
    }

    public function getIterator(): Traversable
    {
        return new ArrayIterator($this->worlds);
    }

    public function actual(): string
    {
        if ($this->actual === null) {
            throw new RuntimeException('The model has no worlds yet.');
        }
        return $this->actual;
    }

    public function setActual(string $id): self
    {
        $this->world($id); // validates
        $this->actual = $id;
        return $this;
    }

    /** @return string[] every atom with an explicit value in any world */
    public function allAtoms(): array
    {
        $atoms = [];
        foreach ($this->worlds as $world) {
            foreach ($world->knownAtoms() as $atom) {
                $atoms[$atom] = true;
            }
        }
        return array_map('strval', array_keys($atoms));
    }

    /* ---- accessibility ------------------------------------------------ */

    public function connect(string $from, string $to): self
    {
        $this->world($from);
        $this->world($to);
        $this->access[$from][$to] = true;
        return $this;
    }

    public function connectBoth(string $a, string $b): self
    {
        return $this->connect($a, $b)->connect($b, $a);
    }

    public function disconnect(string $from, string $to): self
    {
        $this->world($from);
        unset($this->access[$from][$to]);
        return $this;
    }

    public function isAccessible(string $from, string $to): bool
    {
        return isset($this->access[$from][$to]);
    }

    /** @return string[] worlds accessible from $id */
    public function accessibleFrom(string $id): array
    {
        $this->world($id);
        return array_map('strval', array_keys($this->access[$id]));
    }

    /** @return array<int,array{0:string,1:string}> every (from, to) pair in R */
    public function relation(): array
    {
        $pairs = [];
        foreach ($this->ids() as $from) {
            foreach ($this->accessibleFrom($from) as $to) {
                $pairs[] = [$from, $to];
            }
        }
        return $pairs;
    }

    /**
     * Rebuild R from a rule: connect(a, b) whenever $rule($a, $b) is true.
     *
     * @param callable(ModalWorldObject,ModalWorldObject):bool $rule
     */
    public function buildAccessibility(callable $rule): self
    {
        foreach ($this->ids() as $id) {
            $this->access[$id] = [];
        }
        foreach ($this->worlds as $from) {
            foreach ($this->worlds as $to) {
                if ($rule($from, $to)) {
                    $this->connect($from->id(), $to->id());
                }
            }
        }
        return $this;
    }

    /* ---- frame properties --------------------------------------------- */

    public function isReflexive(): bool
    {
        foreach ($this->ids() as $w) {
            if (!$this->isAccessible($w, $w)) {
                return false;
            }
        }
        return true;
    }

    /** Every world sees at least one world. */
    public function isSerial(): bool
    {
        foreach ($this->ids() as $w) {
            if ($this->accessibleFrom($w) === []) {
                return false;
            }
        }
        return true;
    }

    public function isSymmetric(): bool
    {
        foreach ($this->relation() as [$from, $to]) {
            if (!$this->isAccessible($to, $from)) {
                return false;
            }
        }
        return true;
    }

    public function isTransitive(): bool
    {
        foreach ($this->ids() as $w) {
            foreach ($this->accessibleFrom($w) as $u) {
                foreach ($this->accessibleFrom($u) as $v) {
                    if (!$this->isAccessible($w, $v)) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    /** If w sees u and w sees v then u sees v. */
    public function isEuclidean(): bool
    {
        foreach ($this->ids() as $w) {
            $seen = $this->accessibleFrom($w);
            foreach ($seen as $u) {
                foreach ($seen as $v) {
                    if (!$this->isAccessible($u, $v)) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    public function hasCondition(string $condition): bool
    {
        switch ($condition) {
            case 'serial':     return $this->isSerial();
            case 'reflexive':  return $this->isReflexive();
            case 'symmetric':  return $this->isSymmetric();
            case 'transitive': return $this->isTransitive();
            case 'euclidean':  return $this->isEuclidean();
        }
        throw new InvalidArgumentException("Unknown frame condition '$condition'.");
    }

    /** Does the frame meet every condition of the named system (K, D, T, B, S4, S5)? */
    public function conformsTo(string $system): bool
    {
        foreach (ModalSystem::conditions($system) as $condition) {
            if (!$this->hasCondition($condition)) {
                return false;
            }
        }
        return true;
    }

    /* ---- closing R under a condition (adds the fewest edges it can) ---- */

    public function makeReflexive(): bool
    {
        $changed = false;
        foreach ($this->ids() as $w) {
            if (!$this->isAccessible($w, $w)) {
                $this->connect($w, $w);
                $changed = true;
            }
        }
        return $changed;
    }

    /** Dead-end worlds get a loop to themselves. */
    public function makeSerial(): bool
    {
        $changed = false;
        foreach ($this->ids() as $w) {
            if ($this->accessibleFrom($w) === []) {
                $this->connect($w, $w);
                $changed = true;
            }
        }
        return $changed;
    }

    public function makeSymmetric(): bool
    {
        $changed = false;
        foreach ($this->relation() as [$from, $to]) {
            if (!$this->isAccessible($to, $from)) {
                $this->connect($to, $from);
                $changed = true;
            }
        }
        return $changed;
    }

    public function makeTransitive(): bool
    {
        $changed = false;
        do {
            $added = false;
            foreach ($this->ids() as $w) {
                foreach ($this->accessibleFrom($w) as $u) {
                    foreach ($this->accessibleFrom($u) as $v) {
                        if (!$this->isAccessible($w, $v)) {
                            $this->connect($w, $v);
                            $added = $changed = true;
                        }
                    }
                }
            }
        } while ($added);
        return $changed;
    }

    public function makeEuclidean(): bool
    {
        $changed = false;
        do {
            $added = false;
            foreach ($this->ids() as $w) {
                $seen = $this->accessibleFrom($w);
                foreach ($seen as $u) {
                    foreach ($seen as $v) {
                        if (!$this->isAccessible($u, $v)) {
                            $this->connect($u, $v);
                            $added = $changed = true;
                        }
                    }
                }
            }
        } while ($added);
        return $changed;
    }

    private function close(string $condition): bool
    {
        switch ($condition) {
            case 'serial':     return $this->makeSerial();
            case 'reflexive':  return $this->makeReflexive();
            case 'symmetric':  return $this->makeSymmetric();
            case 'transitive': return $this->makeTransitive();
            case 'euclidean':  return $this->makeEuclidean();
        }
        throw new InvalidArgumentException("Unknown frame condition '$condition'.");
    }

    /** Add edges until the frame fits the named system. */
    public function enforce(string $system): self
    {
        $conditions = ModalSystem::conditions($system);
        do {
            $changed = false;
            foreach ($conditions as $condition) {
                $changed = $this->close($condition) || $changed;
            }
        } while ($changed);
        return $this;
    }

    /* ---- evaluation --------------------------------------------------- */

    /** Truth at $worldId, or at the actual world when omitted. */
    public function evaluate(Formula $formula, ?string $worldId = null): bool
    {
        return $formula->holdsAt($this, $worldId ?? $this->actual());
    }

    /** @return string[] worlds of this model where the formula is true */
    public function extension(Formula $formula): array
    {
        return array_values(array_filter(
            $this->ids(),
            function (string $id) use ($formula): bool {
                return $formula->holdsAt($this, $id);
            }
        ));
    }

    /** True at every world under this model's valuation. */
    public function trueEverywhere(Formula $formula): bool
    {
        return count($this->extension($formula)) === count($this->worlds);
    }

    /** @return string[] counterexamples (for □) or witnesses (for ◇) */
    public function witnesses(Formula $formula, ?string $worldId = null): array
    {
        return $formula->witnesses($this, $worldId ?? $this->actual());
    }

    /**
     * Start checking this model. Strict mode throws AssertionFailed on the first failure;
     * pass false to collect every result into a report instead.
     */
    public function assertions(bool $strict = true): ModalAssertions
    {
        return new ModalAssertions($this, $strict);
    }

    /**
     * Frame validity: is the formula true at every world under EVERY valuation of its
     * atoms on this frame? Brute force over 2^(worlds × atoms) valuations, so it is
     * capped by $maxBits (default 2^20 valuations).
     */
    public function frameValidates(Formula $formula, int $maxBits = 20): bool
    {
        $atoms = $formula->atoms();
        $ids   = $this->ids();
        $bits  = count($ids) * count($atoms);

        if ($bits > min($maxBits, 30)) {
            throw new RuntimeException(
                "Checking validity needs 2^$bits valuations, over the limit of 2^$maxBits."
            );
        }

        $scratch = $this->blankCopy();
        $total   = 1 << $bits;

        for ($mask = 0; $mask < $total; $mask++) {
            $bit = 0;
            foreach ($ids as $id) {
                $world = $scratch->world($id);
                foreach ($atoms as $atom) {
                    $world->assign($atom, (($mask >> $bit) & 1) === 1);
                    $bit++;
                }
            }
            foreach ($ids as $id) {
                if (!$formula->holdsAt($scratch, $id)) {
                    return false;
                }
            }
        }
        return true;
    }

    /** Same worlds (ids only) and the same R, with an empty valuation. */
    private function blankCopy(): self
    {
        $copy = new self();
        foreach ($this->ids() as $id) {
            $copy->addWorld(new ModalWorldObject($id));
        }
        $copy->access = $this->access;
        $copy->actual = $this->actual;
        return $copy;
    }

    /* ---- display ------------------------------------------------------ */

    public function render(): string
    {
        $atoms = $this->allAtoms();
        $lines = [];
        foreach ($this->ids() as $id) {
            $world   = $this->world($id);
            $marker  = $id === $this->actual ? '*' : ' ';
            $lines[] = sprintf(
                '%s %s  {%s}  R→{%s}',
                $marker,
                $world,
                $world->literals($atoms),
                implode(', ', $this->accessibleFrom($id))
            );
        }
        return implode(PHP_EOL, $lines) . PHP_EOL . '(* = actual world)';
    }
}

/* ------------------------------------------------------------------------ *
 * Assertions
 * ------------------------------------------------------------------------ */

final class AssertionFailed extends RuntimeException
{
}

/**
 * Checks on one model. Every method returns $this, so they chain:
 *
 *   $model->assertions()
 *         ->holdsAt($p->box(), 'w0')
 *         ->validOnFrame(ModalSystem::axiom('K'));
 *
 * Strict mode (default) throws AssertionFailed on the first failure, with an explanation
 * that names the refuting or supporting worlds. Collect mode records every result and
 * leaves the verdict to summary(), allPassed() and results().
 */
final class ModalAssertions
{
    private ModalWorlds $model;
    private bool $strict;

    /** @var array<int,array{label:string,passed:bool,detail:string}> */
    private array $results = [];

    public function __construct(ModalWorlds $model, bool $strict = true)
    {
        $this->model  = $model;
        $this->strict = $strict;
    }

    /** The primitive every other assertion is built on. */
    public function that(bool $condition, string $label, string $detail = ''): self
    {
        $this->results[] = [
            'label'  => $label,
            'passed' => $condition,
            'detail' => $condition ? '' : $detail,
        ];
        if (!$condition && $this->strict) {
            throw new AssertionFailed($detail === '' ? $label : $label . ' — ' . $detail);
        }
        return $this;
    }

    /* ---- truth in the model ------------------------------------------- */

    /** The formula is true at $world (default: the actual world). */
    public function holdsAt(Formula $formula, ?string $world = null, string $label = ''): self
    {
        $w  = $world ?? $this->model->actual();
        $ok = $formula->holdsAt($this->model, $w);
        return $this->that(
            $ok,
            $label !== '' ? $label : "$formula holds at $w",
            $ok ? '' : $this->explain($formula, $w)
        );
    }

    /** The formula is false at $world (default: the actual world). */
    public function failsAt(Formula $formula, ?string $world = null, string $label = ''): self
    {
        $w  = $world ?? $this->model->actual();
        $ok = !$formula->holdsAt($this->model, $w);
        return $this->that(
            $ok,
            $label !== '' ? $label : "$formula fails at $w",
            $ok ? '' : $this->explain($formula, $w)
        );
    }

    /** True at every world under this model's valuation. */
    public function holdsEverywhere(Formula $formula, string $label = ''): self
    {
        $bad = array_values(array_diff($this->model->ids(), $this->model->extension($formula)));
        return $this->that(
            $bad === [],
            $label !== '' ? $label : "$formula holds at every world",
            'false at ' . implode(', ', $bad)
        );
    }

    /** Both formulas are true at exactly the same worlds of this model. */
    public function equivalentHere(Formula $a, Formula $b, string $label = ''): self
    {
        $x    = $this->model->extension($a);
        $y    = $this->model->extension($b);
        $diff = array_merge(array_diff($x, $y), array_diff($y, $x));
        return $this->that(
            $diff === [],
            $label !== '' ? $label : "$a ≡ $b in this model",
            'they differ at ' . implode(', ', $diff)
        );
    }

    /** $formula's witnesses at $world (counterexamples for □, supporters for ◇) are exactly $expected. */
    public function witnessesAre(Formula $formula, string $world, array $expected, string $label = ''): self
    {
        $got  = $formula->witnesses($this->model, $world);
        $want = array_map('strval', $expected);
        sort($got);
        sort($want);
        return $this->that(
            $got === $want,
            $label !== '' ? $label : "witnesses of $formula at $world are {" . implode(', ', $want) . '}',
            'got {' . implode(', ', $got) . '}'
        );
    }

    /* ---- validity on the frame ---------------------------------------- */

    /** True at every world under EVERY valuation of its atoms (brute force, see frameValidates). */
    public function validOnFrame(Formula $formula, string $label = ''): self
    {
        return $this->that(
            $this->model->frameValidates($formula),
            $label !== '' ? $label : "$formula is valid on this frame",
            'some valuation makes it false at some world'
        );
    }

    public function invalidOnFrame(Formula $formula, string $label = ''): self
    {
        return $this->that(
            !$this->model->frameValidates($formula),
            $label !== '' ? $label : "$formula is not valid on this frame",
            'it is true at every world under every valuation'
        );
    }

    /** $a ↔ $b is valid on the frame. */
    public function equivalentOnFrame(Formula $a, Formula $b, string $label = ''): self
    {
        return $this->that(
            $this->model->frameValidates($a->iff($b)),
            $label !== '' ? $label : "$a ≡ $b on this frame",
            'some valuation separates them'
        );
    }

    /* ---- the accessibility relation ------------------------------------ */

    public function accessible(string $from, string $to, string $label = ''): self
    {
        return $this->that(
            $this->model->isAccessible($from, $to),
            $label !== '' ? $label : "$from R $to",
            'accessible from ' . $from . ': ' . $this->listOrNone($this->model->accessibleFrom($from))
        );
    }

    public function inaccessible(string $from, string $to, string $label = ''): self
    {
        return $this->that(
            !$this->model->isAccessible($from, $to),
            $label !== '' ? $label : "not $from R $to",
            "$to is accessible from $from"
        );
    }

    public function hasCondition(string $condition, string $label = ''): self
    {
        return $this->that(
            $this->model->hasCondition($condition),
            $label !== '' ? $label : "frame is $condition",
            "the frame is not $condition"
        );
    }

    public function lacksCondition(string $condition, string $label = ''): self
    {
        return $this->that(
            !$this->model->hasCondition($condition),
            $label !== '' ? $label : "frame is not $condition",
            "the frame is $condition"
        );
    }

    /** The frame meets every condition of K, D, T, B, S4 or S5. */
    public function conformsTo(string $system, string $label = ''): self
    {
        $missing = array_values(array_filter(
            ModalSystem::conditions($system),
            function (string $condition): bool {
                return !$this->model->hasCondition($condition);
            }
        ));
        return $this->that(
            $missing === [],
            $label !== '' ? $label : "frame conforms to $system",
            'not ' . implode(', not ', $missing)
        );
    }

    /* ---- reporting ----------------------------------------------------- */

    /** @return array<int,array{label:string,passed:bool,detail:string}> */
    public function results(): array
    {
        return $this->results;
    }

    public function passedCount(): int
    {
        return count(array_filter($this->results, function (array $r): bool {
            return $r['passed'];
        }));
    }

    public function failedCount(): int
    {
        return count($this->results) - $this->passedCount();
    }

    public function allPassed(): bool
    {
        return $this->failedCount() === 0;
    }

    public function summary(): string
    {
        $lines = [];
        foreach ($this->results as $r) {
            $lines[] = ($r['passed'] ? '  ✓ ' : '  ✗ ') . $r['label']
                     . ($r['passed'] || $r['detail'] === '' ? '' : ' — ' . $r['detail']);
        }
        $lines[] = sprintf('%d passed, %d failed', $this->passedCount(), $this->failedCount());
        return implode(PHP_EOL, $lines);
    }

    /* ---- helpers ------------------------------------------------------- */

    /** @param string[] $ids */
    private function listOrNone(array $ids): string
    {
        return $ids === [] ? 'none' : implode(', ', $ids);
    }

    /** Why a formula has the truth value it has at $world, naming the worlds responsible. */
    private function explain(Formula $formula, string $world): string
    {
        $actual = $formula->holdsAt($this->model, $world);
        $text   = "$formula is " . ($actual ? 'true' : 'false') . " at $world";
        $core   = $formula->core();

        if ($core instanceof Box || $core instanceof Diamond) {
            $seen  = $this->model->accessibleFrom($world);
            $reach = $seen === []
                ? "nothing is accessible from $world"
                : "accessible from $world: " . implode(', ', $seen);
            $who   = $core->witnesses($this->model, $world);

            if ($core instanceof Box) {
                if (!$actual) {
                    $text .= '; refuted at ' . implode(', ', $who) . " ($reach)";
                } else {
                    $text .= $seen === [] ? "; vacuously true ($reach)" : "; no accessible world refutes it ($reach)";
                }
            } else {
                $text .= $actual
                    ? '; witnessed at ' . implode(', ', $who) . " ($reach)"
                    : "; no accessible world satisfies it ($reach)";
            }
        }
        return $text;
    }
}

/* ------------------------------------------------------------------------ *
 * Demo (only runs when this file is executed directly: php modal_worlds.php)
 * ------------------------------------------------------------------------ */

function verdict(bool $value): string
{
    return $value ? 'true' : 'false';
}

function runDemo(): void
{
    $P = Formula::atom('P');
    $Q = Formula::atom('Q');

    /* 1. A small model -------------------------------------------------- */
    echo "== 1. A small Kripke model ==\n";
    $m = new ModalWorlds();
    $m->addWorld(new ModalWorldObject('w0', ['P', 'Q'], 'actual'))
      ->addWorld(new ModalWorldObject('w1', ['P']))
      ->addWorld(new ModalWorldObject('w2', ['P', 'Q']));
    $m->connect('w0', 'w1')->connect('w0', 'w2')->connect('w1', 'w2');
    echo $m->render(), "\n\n";

    foreach ([$P->box(), $Q->box(), $Q->diamond(), $Q->neg()->box()->neg()] as $f) {
        printf("at w0:  %-6s %-5s  (%s)\n", $f, verdict($m->evaluate($f, 'w0')), $f->english());
    }
    echo "\n□Q fails at w0 because of: ", implode(', ', $m->witnesses($Q->box(), 'w0')), "\n";
    echo "◇Q holds at w0 thanks to:  ", implode(', ', $m->witnesses($Q->diamond(), 'w0')), "\n";

    $dual = $m->extension($P->diamond()) === $m->extension($P->neg()->box()->neg())
         && $m->extension($Q->diamond()) === $m->extension($Q->neg()->box()->neg());
    echo "Duality ◇P ≡ ¬□¬P holds at every world: ", verdict($dual), "\n";
    echo "□¬P at w2 (a dead end, so vacuously true even though P holds there): ",
         verdict($m->evaluate($P->neg()->box(), 'w2')), "\n\n";

    /* 2. Kinds of necessity -------------------------------------------- */
    echo "== 2. Logical vs physical necessity ==\n";
    foreach (NecessityType::all() as $type) {
        echo "- ", $type, ': ', NecessityType::describe($type), "\n";
    }

    $speed = Formula::atom('SpeedLimit');
    $lem   = $P->disj($P->neg()); // P ∨ ¬P

    $n = new ModalWorlds();
    $n->addWorld(new ModalWorldObject('actual', ['Rain', 'SpeedLimit'], 'our world', '', ['laws' => 'ours']))
      ->addWorld(new ModalWorldObject('dry', ['SpeedLimit'], 'a dry world', '', ['laws' => 'ours']))
      ->addWorld(new ModalWorldObject('faster', [], 'different physics', '', ['laws' => 'alt']));

    $n->buildAccessibility(function (ModalWorldObject $a, ModalWorldObject $b): bool {
        return $a->meta('laws') === $b->meta('laws');
    });
    echo "\nPhysical necessity (R = same laws):\n";
    printf("  □%s at actual: %s\n", $speed, verdict($n->evaluate($speed->box())));
    printf("  □%s at actual: %s\n", $lem, verdict($n->evaluate($lem->box())));

    $n->buildAccessibility(function (): bool {
        return true;
    });
    echo "Logical necessity (R links every world):\n";
    printf("  □%s at actual: %s\n", $speed, verdict($n->evaluate($speed->box())));
    printf("  □%s at actual: %s\n\n", $lem, verdict($n->evaluate($lem->box())));

    /* 3. Systems and frame correspondence ------------------------------ */
    echo "== 3. Axioms vs frame conditions ==\n";
    $f = new ModalWorlds();
    $f->addWorld(new ModalWorldObject('a'))
      ->addWorld(new ModalWorldObject('b'))
      ->addWorld(new ModalWorldObject('c'));
    $f->connect('a', 'b')->connect('b', 'c');

    $table = function (ModalWorlds $frame, string $title): void {
        echo "\n$title\n";
        foreach (ModalSystem::axiomNames() as $axiom) {
            $condition = ModalSystem::axiomCondition($axiom);
            printf(
                "  axiom %-2s  valid on frame: %-5s  frame is %s\n",
                $axiom,
                verdict($frame->frameValidates(ModalSystem::axiom($axiom))),
                $condition === null ? '(any frame)' : $condition . ': ' . verdict($frame->hasCondition($condition))
            );
        }
    };

    echo "R: a→b, b→c";
    $table($f, 'Before enforcing anything:');

    $f->enforce(ModalSystem::S4);
    echo "\nAfter enforce('S4') the relation is: ";
    echo implode(' ', array_map(function (array $pair): string {
        return $pair[0] . '→' . $pair[1];
    }, $f->relation())), "\n";
    echo "Conforms to S4: ", verdict($f->conformsTo('S4')), "; to S5: ", verdict($f->conformsTo('S5')), "\n";
    $table($f, 'After enforce(S4): D, T and 4 now hold; B and 5 still fail.');

    $f->enforce(ModalSystem::S5);
    echo "\nAfter enforce('S5'), conforms to S5: ", verdict($f->conformsTo('S5')), "\n";

    /* 4. let ------------------------------------------------------------ */
    echo "\n== 4. let: naming sub-formulas ==\n";
    echo "let Safe := □P in let Hopeful := ◇Q in (Safe ∧ Hopeful)\n";
    $named = Formula::let('Safe', $P->box(), function (Formula $safe) use ($Q): Formula {
        return Formula::let('Hopeful', $Q->diamond(), function (Formula $hopeful) use ($safe): Formula {
            return $safe->conj($hopeful);
        });
    });
    echo "  as written: ", $named, "\n";
    echo "  unfolded:   ", $named->unfold(), "\n";
    echo "  at w0 of model 1: ", verdict($m->evaluate($named, 'w0')), "\n";

    // The name can be reused, and the body can build on it.
    $reused = Formula::let('Safe', $P->box(), function (Formula $safe): Formula {
        return $safe->implies($safe->box());   // Safe → □Safe, which is axiom 4 for □P
    });
    echo "  reuse:      ", $reused, "  =  ", $reused->unfold(), "\n";
    echo "  valid on model 1's frame: ", verdict($m->frameValidates($reused)),
         " (the frame is transitive: ", verdict($m->isTransitive()), ")\n";

    /* 5. Assertions ----------------------------------------------------- */
    echo "\n== 5. Assertions (collect mode) ==\n";
    $check = $m->assertions(false);   // false = record results instead of throwing
    $check
        ->holdsAt($P->box(), 'w0')
        ->failsAt($Q->box(), 'w0')
        ->holdsAt($Q->box(), 'w0', 'deliberate failure: □Q at w0')
        ->holdsAt($P->neg()->box(), 'w2', 'vacuous □¬P at the dead end w2')
        ->accessible('w0', 'w1')
        ->inaccessible('w2', 'w0')
        ->witnessesAre($Q->box(), 'w0', ['w1'])
        ->equivalentHere($P->diamond(), $P->neg()->box()->neg(), 'duality ◇P ≡ ¬□¬P in this model')
        ->equivalentOnFrame($P->diamond(), $P->neg()->box()->neg(), 'duality ◇P ≡ ¬□¬P on this frame')
        ->validOnFrame(ModalSystem::axiom('K'), 'axiom K is valid on every frame')
        ->invalidOnFrame(ModalSystem::axiom('T'), 'axiom T is not valid here (R is not reflexive)')
        ->lacksCondition('reflexive');
    echo $check->summary(), "\n";
    echo "All passed? ", verdict($check->allPassed()), " (one failure was deliberate)\n";

    echo "\nStrict mode throws on the first failure:\n";
    try {
        $m->assertions()->holdsAt($Q->box(), 'w0');
    } catch (AssertionFailed $e) {
        echo "  AssertionFailed: ", $e->getMessage(), "\n";
    }
    try {
        $m->assertions()->holdsAt($Q->diamond(), 'w2');
    } catch (AssertionFailed $e) {
        echo "  AssertionFailed: ", $e->getMessage(), "\n";
    }
}

if (PHP_SAPI === 'cli' && isset($_SERVER['argv'][0]) && realpath($_SERVER['argv'][0]) === __FILE__) {
    runDemo();
}
