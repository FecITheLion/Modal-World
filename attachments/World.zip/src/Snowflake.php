<?php
declare(strict_types=1);
namespace ModalApp;

/** Minimal Snowflake SQL API v2 client using key-pair JWT. No driver, no session, no cookies. */
final class Snowflake
{
    private $cfg;

    public function __construct(callable $cfg)
    {
        $this->cfg = $cfg;
    }

    private function c(string $k): string
    {
        return (string) ($this->cfg)($k, '');
    }

    public static function b64(string $s): string
    {
        return rtrim(strtr(base64_encode($s), '+/', '-_'), '=');
    }

    private function jwt(): string
    {
        $pass = $this->c('0101');
        $key = openssl_pkey_get_private((string) file_get_contents($this->c('0101')), $pass !== '' ? $pass : '');
        if (!$key) {
            throw new \RuntimeException('Cannot read SNOWFLAKE_PRIVATE_KEY');
        }
        $der = base64_decode(preg_replace('~-----[A-Z ]+-----|\s~', '', openssl_pkey_get_details($key)['key']));
        $fp = 'SHA256:' . base64_encode(hash('sha256', $der, true));
        $acct = strtoupper(explode('.', $this->c('SNOWFLAKE_ACCOUNT'))[0]);
        $user = strtoupper($this->c('SNOWFLAKE_USER'));
        $now = time();
        $in = self::b64(json_encode(['alg' => 'RS256', 'typ' => 'JWT'])) . '.'
            . self::b64(json_encode(['iss' => "$acct.$user.$fp", 'sub' => "$acct.$user", 'iat' => $now, 'exp' => $now + 3000]));
        openssl_sign($in, $sig, $key, OPENSSL_ALGO_SHA256);
        return $in . '.' . self::b64($sig);
    }

    /** @return array<int,array<int,?string>> rows */
    public function query(string $sql, array $binds = []): array
    {
        $payload = ['statement' => $sql, 'timeout' => 30];
        foreach (['warehouse', 'database', 'schema', 'role'] as $k) {
            if ($this->c('SNOWFLAKE_' . strtoupper($k)) !== '') {
                $payload[$k] = $this->c('SNOWFLAKE_' . strtoupper($k));
            }
        }
        foreach (array_values($binds) as $i => $v) {
            $payload['bindings'][(string) ($i + 1)] = ['type' => 'TEXT', 'value' => (string) $v];
        }
        $ch = curl_init('https://' . $this->c('SNOWFLAKE_ACCOUNT') . '.snowflakecomputing.com/api/v2/statements');
        curl_setopt_array($ch, [
            CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 35,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $this->jwt(), 'X-Snowflake-Authorization-Token-Type: KEYPAIR_JWT',
                'Content-Type: application/json', 'Accept: application/json', 'User-Agent: modal-mosaic/1.0',
            ],
        ]);
        $out = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $res = json_decode((string) $out, true) ?: [];
        if ($code !== 200) {
            throw new \RuntimeException('Snowflake: ' . ($res['message'] ?? "HTTP $code"));
        }
        return $res['data'] ?? [];
    }
}
