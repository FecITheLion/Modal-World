<?php
declare(strict_types=1);
namespace ModalApp;

/**
 * OAuth 2.0 authorization-code + PKCE driven by JSON-LD "login instructions" kept in Snowflake.
 * Stateless and cookie-free: the PKCE verifier travels inside an encrypted, expiring `state`,
 * and the finished token goes back to the browser in a URL fragment (never stored here).
 */
final class OAuth
{
    private const REQUIRED = ['authorizationEndpoint', 'tokenEndpoint', 'redirectUri', 'clientId', 'scope'];
    private $db;
    private $cfg;
    private $dir;

    public function __construct(Snowflake $db, callable $cfg, string $cacheDir)
    {
        $this->db = $db;
        $this->cfg = $cfg;
        $this->dir = $cacheDir;
    }

    /** Load, cache for 5 minutes, and validate one provider's JSON-LD instructions. */
    public function instructions(string $id): array
    {
        $file = $this->dir . '/oauth-' . sha1($id) . '.json';
        if (is_file($file) && filemtime($file) > time() - 300) {
            $json = (string) file_get_contents($file);
        } else {
            $rows = $this->db->query('SELECT TO_JSON(DOC) FROM OAUTH_LOGIN_INSTRUCTIONS WHERE ID = ?', [$id]);
            if (!$rows) {
                throw new \RuntimeException("No login instructions for '$id'");
            }
            $json = (string) $rows[0][0];
            file_put_contents($file, $json, LOCK_EX);
        }
        $doc = json_decode($json, true);
        $ctx = is_array($doc['@context'] ?? null) ? implode(' ', $doc['@context']) : (string) ($doc['@context'] ?? '');
        if (!is_array($doc) || ($doc['@type'] ?? '') !== 'OAuthLoginInstructions' || substr($ctx, -13) !== '/schema/oauth') {
            throw new \RuntimeException('Instructions do not match the oauth JSON-LD schema');
        }
        foreach (self::REQUIRED as $k) {
            if (empty($doc[$k])) {
                throw new \RuntimeException("Instructions missing '$k'");
            }
        }
        foreach (['authorizationEndpoint', 'tokenEndpoint'] as $k) {
            if (stripos((string) $doc[$k], 'https://') !== 0) {
                throw new \RuntimeException("$k must be https");
            }
        }
        return $doc;
    }

    /** Insert or replace a provider's instructions (JSON text) in Snowflake. */
    public function store(string $id, array $doc): void
    {
        $this->db->query('MERGE INTO OAUTH_LOGIN_INSTRUCTIONS t USING (SELECT ? ID, PARSE_JSON(?) DOC) s ON t.ID = s.ID '
            . 'WHEN MATCHED THEN UPDATE SET DOC = s.DOC, UPDATED_AT = CURRENT_TIMESTAMP() '
            . 'WHEN NOT MATCHED THEN INSERT (ID, DOC) VALUES (s.ID, s.DOC)', [$id, json_encode($doc)]);
        @unlink($this->dir . '/oauth-' . sha1($id) . '.json');
    }

    private function key(): string
    {
        return hash('sha256', (string) ($this->cfg)('APP_SECRET', ''), true);
    }

    private function seal(array $p): string
    {
        $n = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        return Snowflake::b64($n . sodium_crypto_secretbox(json_encode($p), $n, $this->key()));
    }

    private function open(string $s): ?array
    {
        $raw = base64_decode(strtr($s, '-_', '+/'), true);
        if ($raw === false || strlen($raw) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES) {
            return null;
        }
        $plain = sodium_crypto_secretbox_open(substr($raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), substr($raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), $this->key());
        $p = $plain === false ? null : json_decode($plain, true);
        return is_array($p) && ($p['exp'] ?? 0) > time() ? $p : null;
    }

    public function loginUrl(string $id): string
    {
        $ins = $this->instructions($id);
        $verifier = Snowflake::b64(random_bytes(32));
        $q = http_build_query([
            'response_type' => 'code', 'client_id' => $ins['clientId'], 'redirect_uri' => $ins['redirectUri'],
            'scope' => implode(' ', (array) $ins['scope']),
            'state' => $this->seal(['id' => $id, 'v' => $verifier, 'exp' => time() + 600]),
            'code_challenge' => Snowflake::b64(hash('sha256', $verifier, true)), 'code_challenge_method' => 'S256',
        ], '', '&', PHP_QUERY_RFC3986);
        return $ins['authorizationEndpoint'] . (strpos($ins['authorizationEndpoint'], '?') === false ? '?' : '&') . $q;
    }

    /** Trade the code for tokens. Nothing is kept. */
    public function exchange(string $code, string $state): array
    {
        $st = $this->open($state);
        if ($st === null || $code === '') {
            throw new \RuntimeException('Invalid or expired login state');
        }
        $ins = $this->instructions((string) $st['id']);
        $form = ['grant_type' => 'authorization_code', 'code' => $code, 'redirect_uri' => $ins['redirectUri'],
                 'client_id' => $ins['clientId'], 'code_verifier' => $st['v']];
        if (!empty($ins['clientSecretEnv'])) {
            $form['client_secret'] = (string) ($this->cfg)($ins['clientSecretEnv'], '');
        }
        $ch = curl_init($ins['tokenEndpoint']);
        curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20,
            CURLOPT_POSTFIELDS => http_build_query($form), CURLOPT_HTTPHEADER => ['Accept: application/json']]);
        $res = json_decode((string) curl_exec($ch), true);
        curl_close($ch);
        if (!is_array($res) || empty($res['access_token'])) {
            throw new \RuntimeException('Token endpoint refused the code');
        }
        return $res;
    }
}
