<?php
declare(strict_types=1);
namespace ModalApp;

/** Logic symbols that can be evaluated at, or quantified over, worlds. "# Title" opens a group; rows are sym|name|reading. */
final class Symbols
{
    private const DATA = <<<'TXT'
# Propositional
¬|negation|not P: true at w iff P is false at w
∧|conjunction|P and Q both true at w
∨|disjunction|at least one of P, Q true at w
→|implication|if P then Q at w
↔|biconditional|P and Q have the same truth value at w
⊕|exclusive or|exactly one of P, Q is true
↑|NAND (Sheffer)|not both P and Q
↓|NOR (Peirce)|neither P nor Q
⊤|verum|true at every world
⊥|falsum|true at no world
≡|equivalence|true at exactly the same worlds
# Alethic modal
□|necessity|P at every accessible world
◇|possibility|P at some accessible world
⇒|strict implication|□(P → Q)
Δ|non-contingency|□P ∨ □¬P
∇|contingency|◇P ∧ ◇¬P
⟨a⟩|diamond (action a)|some a-successor satisfies P
[a]|box (action a)|every a-successor satisfies P
# Frames and models
R|accessibility|wRv: v is possible relative to w
W|set of worlds|the domain of the model
V|valuation|assigns atoms to the worlds where they hold
⊩|forces|w ⊩ P: P holds at w
⊨|entails|truth in a model; semantic consequence
⊭|does not entail|P fails in some model or world
⊢|proves|derivable in the system
⊬|does not prove|not derivable
⟦P⟧|extension|the set of worlds where P holds
∈|member of|w ∈ W
⊆|subset|every world of one set is in the other
∩|intersection|worlds in both extensions
∪|union|worlds in either extension
∅|empty set|no worlds
# Quantifiers and identity
∀|for all|every individual (or world) in the domain
∃|exists|some individual in the domain
∃!|exists exactly one|a unique individual
=|identity|the same individual across worlds
≠|distinctness|not the same individual
λ|lambda|abstracts a property from a formula
ι|definite description|the unique individual such that
# Epistemic
K|knows|Kₐ P: agent a knows P (P at all worlds a considers possible)
B|believes|Bₐ P: agent a believes P
E|everyone knows|every agent in the group knows P
C|common knowledge|everyone knows that everyone knows, without end
D|distributed knowledge|what the group knows by pooling
[!P]|public announcement|after P is announced truthfully
# Deontic
O|obligatory|P at every ideal world
P|permitted|P at some ideal world
F|forbidden|O¬P
# Temporal
G|always (future)|P at all later times
F|eventually|P at some later time
X|next|P at the next step
U|until|P holds until Q does
R|release|Q holds until and including when P does
W|weak until|U, or P forever
H|always (past)|P at all earlier times
S|since|Q held since P
A|all paths|on every branch (CTL)
E|some path|on some branch (CTL)
# Dynamic and fixpoint
;|sequence|do a, then b
*|iteration|repeat zero or more times
?|test|continue only if P holds
μ|least fixpoint|smallest set closed under the formula
ν|greatest fixpoint|largest set consistent with the formula
# Proof marks
∴|therefore|conclusion follows
∵|because|reason given
∎|end of proof|Q.E.D.
TXT;

    /** @return array<int,array{title:string,items:array}> */
    public static function groups(): array
    {
        $out = [];
        foreach (preg_split('~\R~', self::DATA) as $line) {
            if ($line === '') {
                continue;
            }
            if ($line[0] === '#') {
                $out[] = ['title' => trim(substr($line, 1)), 'items' => []];
                continue;
            }
            $line = explode('|', $line, 3);
            $out[count($out) - 1]['items'][] = ['sym' => $line[0] ?? null, 'name' => $line[1] ?? null, 'read' => $line[2] ?? null];
        }
        return $out;
    }
}
